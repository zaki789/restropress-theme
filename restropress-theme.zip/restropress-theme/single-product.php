<?php
/**
 * The template for displaying single products
 *
 * @package RestroPress
 * @version 1.0.0
 */

get_header();
?>

<div class="rp-container">
    <div class="rp-content-area">
        <?php while (have_posts()) : the_post(); ?>
            <?php wc_get_template_part('content', 'single-product'); ?>
        <?php endwhile; ?>
    </div>
</div>

<?php
get_footer();