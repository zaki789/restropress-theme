/**
 * AJAX Menu functionality for RestroPress theme
 * 
 * @package RestroPress
 * @version 1.0.0
 */

(function($) {
    'use strict';

    /**
     * AJAX Menu handler
     */
    const AjaxMenu = {

        /**
         * Initialize AJAX menu functionality
         */
        init: function() {
            this.currentCategory = 0;
            this.currentPage = 1;
            this.currentSearch = '';
            this.currentSort = 'menu_order';
            this.isLoading = false;
            this.hasMore = true;

            this.bindEvents();
            this.loadInitialProducts();
        },

        /**
         * Bind event handlers
         */
        bindEvents: function() {
            // Category filter
            $(document).on('click', '.rp-category-btn', this.handleCategoryFilter.bind(this));
            
            // Search functionality
            $(document).on('input', '.rp-search-input', this.debounce(this.handleSearch.bind(this), 500));
            $(document).on('click', '.rp-search-clear', this.handleSearchClear.bind(this));
            
            // Sort functionality
            $(document).on('change', '.rp-sort-select', this.handleSort.bind(this));
            
            // Load more
            $(document).on('click', '.rp-load-more-button', this.handleLoadMore.bind(this));
            
            // Add to cart
            $(document).on('click', '.rp-add-to-cart', this.handleAddToCart.bind(this));
            
            // Quick view
            $(document).on('click', '.rp-quick-view', this.handleQuickView.bind(this));
            $(document).on('click', '.rp-quick-view-close, .rp-quick-view-backdrop', this.handleQuickViewClose.bind(this));
            
            // Quantity controls
            $(document).on('click', '.rp-quantity-plus, .rp-quantity-minus', this.handleQuantityChange.bind(this));
            
            // Reset filters
            $(document).on('click', '.rp-reset-filters', this.handleResetFilters.bind(this));
            
            // Keyboard navigation
            $(document).on('keydown', this.handleKeyboardNavigation.bind(this));
        },

        /**
         * Load initial products
         */
        loadInitialProducts: function() {
            const $productsGrid = $('.rp-products-grid');
            const $loadingIndicator = $('.rp-products-loading');
            
            this.isLoading = true;
            $productsGrid.addClass('rp-loading');
            
            $.ajax({
                url: rp_ajax.ajax_url,
                type: 'POST',
                data: {
                    action: 'rp_filter_products',
                    category_id: this.currentCategory,
                    search_term: this.currentSearch,
                    sort: this.currentSort,
                    page: this.currentPage,
                    nonce: rp_ajax.nonce
                },
                success: (response) => {
                    if (response.success) {
                        $productsGrid.html(response.data.html);
                        this.updatePagination(response.data);
                        this.animateProducts();
                        this.updateCategoryCounts(response.data);
                    } else {
                        this.showError(response.data);
                    }
                },
                error: () => {
                    this.showError(rp_ajax.error_text);
                },
                complete: () => {
                    this.isLoading = false;
                    $productsGrid.removeClass('rp-loading');
                    $loadingIndicator.remove();
                }
            });
        },

        /**
         * Handle category filter
         */
        handleCategoryFilter: function(e) {
            e.preventDefault();
            
            if (this.isLoading) return;
            
            const $button = $(e.currentTarget);
            const categoryId = $button.data('category-id');
            
            // Update active state
            $('.rp-category-btn').removeClass('active');
            $button.addClass('active');
            
            // Reset to first page
            this.currentPage = 1;
            this.currentCategory = categoryId;
            this.hasMore = true;
            
            this.loadProducts();
        },

        /**
         * Handle search
         */
        handleSearch: function(e) {
            if (this.isLoading) return;
            
            const searchTerm = $(e.currentTarget).val().trim();
            this.currentSearch = searchTerm;
            this.currentPage = 1;
            this.hasMore = true;
            
            // Show/hide clear button
            const $clearButton = $('.rp-search-clear');
            if (searchTerm.length > 0) {
                $clearButton.removeClass('rp-hidden');
            } else {
                $clearButton.addClass('rp-hidden');
            }
            
            // Only search if term is long enough or empty
            if (searchTerm.length >= 2 || searchTerm.length === 0) {
                this.loadProducts();
            }
        },

        /**
         * Handle search clear
         */
        handleSearchClear: function(e) {
            e.preventDefault();
            
            $('.rp-search-input').val('').focus();
            $('.rp-search-clear').addClass('rp-hidden');
            
            this.currentSearch = '';
            this.currentPage = 1;
            this.hasMore = true;
            
            this.loadProducts();
        },

        /**
         * Handle sort change
         */
        handleSort: function(e) {
            if (this.isLoading) return;
            
            this.currentSort = $(e.currentTarget).val();
            this.currentPage = 1;
            this.hasMore = true;
            
            this.loadProducts();
        },

        /**
         * Handle load more
         */
        handleLoadMore: function(e) {
            e.preventDefault();
            
            if (this.isLoading || !this.hasMore) return;
            
            this.currentPage++;
            this.loadProducts(true);
        },

        /**
         * Handle add to cart
         */
        handleAddToCart: function(e) {
            e.preventDefault();
            e.stopPropagation();
            
            if (this.isLoading) return;
            
            const $button = $(e.currentTarget);
            const productId = $button.data('product-id');
            const productName = $button.data('product-name') || 'محصول';
            const $quantityInput = $button.closest('.rp-product-actions').find('.rp-quantity-input');
            const quantity = $quantityInput.length ? parseInt($quantityInput.val()) : 1;
            
            // Disable button and show loading
            $button.prop('disabled', true).addClass('rp-loading');
            
            $.ajax({
                url: rp_ajax.ajax_url,
                type: 'POST',
                data: {
                    action: 'rp_add_to_cart',
                    product_id: productId,
                    quantity: quantity,
                    nonce: rp_ajax.nonce
                },
                success: (response) => {
                    if (response.success) {
                        // Update cart fragments
                        if (response.data.fragments) {
                            $.each(response.data.fragments, function(key, value) {
                                $(key).replaceWith(value);
                            });
                        }
                        
                        // Show success message
                        rpShowNotification(response.data.message, 'success');
                        
                        // Update button state temporarily
                        $button.find('.rp-button-text').text(rp_ajax.added_to_cart_text);
                        setTimeout(() => {
                            $button.find('.rp-button-text').text(rp_ajax.add_to_cart_text);
                        }, 2000);
                        
                    } else {
                        rpShowNotification(response.data, 'error');
                    }
                },
                error: () => {
                    rpShowNotification(rp_ajax.error_text, 'error');
                },
                complete: () => {
                    $button.prop('disabled', false).removeClass('rp-loading');
                }
            });
        },

        /**
         * Handle quick view
         */
        handleQuickView: function(e) {
            e.preventDefault();
            e.stopPropagation();
            
            if (this.isLoading) return;
            
            const $button = $(e.currentTarget);
            const productId = $button.data('product-id');
            
            this.openQuickView(productId);
        },

        /**
         * Open quick view modal
         */
        openQuickView: function(productId) {
            const $modal = $('.rp-quick-view-modal');
            const $content = $modal.find('.rp-quick-view-content');
            
            $modal.removeClass('rp-hidden');
            $('body').addClass('rp-modal-open');
            
            // Show loading
            $content.html(`
                <div class="rp-quick-view-loading">
                    <div class="rp-loading-spinner"></div>
                    <p>در حال بارگذاری...</p>
                </div>
            `);
            
            $.ajax({
                url: rp_ajax.ajax_url,
                type: 'POST',
                data: {
                    action: 'rp_quick_view',
                    product_id: productId,
                    nonce: rp_ajax.nonce
                },
                success: (response) => {
                    if (response.success) {
                        $content.html(response.data.html);
                        this.bindQuickViewEvents();
                    } else {
                        $content.html(`
                            <div class="rp-quick-view-error">
                                <i class="fas fa-exclamation-circle"></i>
                                <p>خطا در بارگذاری محصول</p>
                            </div>
                        `);
                    }
                },
                error: () => {
                    $content.html(`
                        <div class="rp-quick-view-error">
                            <i class="fas fa-exclamation-circle"></i>
                            <p>خطا در بارگذاری محصول</p>
                        </div>
                    `);
                }
            });
        },

        /**
         * Handle quick view close
         */
        handleQuickViewClose: function(e) {
            e.preventDefault();
            
            const $modal = $('.rp-quick-view-modal');
            $modal.addClass('rp-hidden');
            $('body').removeClass('rp-modal-open');
            
            // Clear content
            setTimeout(() => {
                $modal.find('.rp-quick-view-content').empty();
            }, 300);
        },

        /**
         * Bind quick view events
         */
        bindQuickViewEvents: function() {
            const $modal = $('.rp-quick-view-modal');
            
            // Quantity controls
            $modal.find('.rp-quantity-plus').on('click', this.handleQuantityChange.bind(this));
            $modal.find('.rp-quantity-minus').on('click', this.handleQuantityChange.bind(this));
            
            // Add to cart in quick view
            $modal.find('.rp-add-to-cart').on('click', this.handleAddToCart.bind(this));
            
            // Gallery navigation
            this.initQuickViewGallery();
            
            // Keyboard navigation
            $modal.on('keydown', this.handleQuickViewKeyboard.bind(this));
        },

        /**
         * Initialize quick view gallery
         */
        initQuickViewGallery: function() {
            const $gallery = $('.rp-quick-view-gallery');
            if ($gallery.length) {
                const $images = $gallery.find('.rp-quick-view-image');
                if ($images.length > 1) {
                    // Add navigation arrows
                    $gallery.prepend(`
                        <button class="rp-gallery-prev" aria-label="تصویر قبلی">
                            <i class="fas fa-chevron-right"></i>
                        </button>
                        <button class="rp-gallery-next" aria-label="تصویر بعدی">
                            <i class="fas fa-chevron-left"></i>
                        </button>
                    `);
                    
                    let currentIndex = 0;
                    
                    // Show first image
                    $images.eq(0).addClass('rp-active');
                    
                    // Navigation handlers
                    $gallery.find('.rp-gallery-prev').on('click', () => {
                        currentIndex = (currentIndex - 1 + $images.length) % $images.length;
                        this.updateGallery(currentIndex, $images);
                    });
                    
                    $gallery.find('.rp-gallery-next').on('click', () => {
                        currentIndex = (currentIndex + 1) % $images.length;
                        this.updateGallery(currentIndex, $images);
                    });
                    
                    // Keyboard navigation
                    $(document).on('keydown.quickview', (e) => {
                        if (e.key === 'ArrowLeft') {
                            currentIndex = (currentIndex - 1 + $images.length) % $images.length;
                            this.updateGallery(currentIndex, $images);
                        } else if (e.key === 'ArrowRight') {
                            currentIndex = (currentIndex + 1) % $images.length;
                            this.updateGallery(currentIndex, $images);
                        }
                    });
                }
            }
        },

        /**
         * Update gallery display
         */
        updateGallery: function(index, $images) {
            $images.removeClass('rp-active');
            $images.eq(index).addClass('rp-active');
        },

        /**
         * Handle quantity change
         */
        handleQuantityChange: function(e) {
            e.preventDefault();
            
            const $button = $(e.currentTarget);
            const $input = $button.siblings('.rp-quantity-input');
            const min = parseInt($input.attr('min')) || 1;
            const max = parseInt($input.attr('max')) || 10;
            let value = parseInt($input.val()) || min;
            
            if ($button.hasClass('rp-quantity-plus')) {
                if (value < max) value++;
            } else {
                if (value > min) value--;
            }
            
            $input.val(value).trigger('change');
        },

        /**
         * Handle reset filters
         */
        handleResetFilters: function(e) {
            e.preventDefault();
            
            // Reset all filters
            $('.rp-category-btn').removeClass('active');
            $('.rp-category-btn[data-category-id="0"]').addClass('active');
            $('.rp-search-input').val('');
            $('.rp-search-clear').addClass('rp-hidden');
            $('.rp-sort-select').val('menu_order');
            
            this.currentCategory = 0;
            this.currentSearch = '';
            this.currentSort = 'menu_order';
            this.currentPage = 1;
            this.hasMore = true;
            
            this.loadProducts();
        },

        /**
         * Handle keyboard navigation
         */
        handleKeyboardNavigation: function(e) {
            // Close modals with Escape key
            if (e.key === 'Escape') {
                if ($('.rp-quick-view-modal').is(':visible')) {
                    this.handleQuickViewClose(e);
                }
            }
        },

        /**
         * Handle quick view keyboard navigation
         */
        handleQuickViewKeyboard: function(e) {
            if (e.key === 'Escape') {
                this.handleQuickViewClose(e);
            }
            
            // Trap focus within modal
            if (e.key === 'Tab') {
                const $focusable = $('.rp-quick-view-modal').find('button, [href], input, select, textarea, [tabindex]:not([tabindex="-1"])');
                const first = $focusable.first();
                const last = $focusable.last();
                
                if (e.shiftKey) {
                    if ($(document.activeElement).is(first)) {
                        last.focus();
                        e.preventDefault();
                    }
                } else {
                    if ($(document.activeElement).is(last)) {
                        first.focus();
                        e.preventDefault();
                    }
                }
            }
        },

        /**
         * Load products with current filters
         */
        loadProducts: function(append = false) {
            if (this.isLoading) return;
            
            const $productsGrid = $('.rp-products-grid');
            const $loadMoreContainer = $('.rp-load-more-container');
            
            this.isLoading = true;
            
            if (!append) {
                $productsGrid.addClass('rp-loading');
                $loadMoreContainer.addClass('rp-hidden');
            } else {
                $('.rp-load-more-button').prop('disabled', true).addClass('rp-loading');
            }
            
            $.ajax({
                url: rp_ajax.ajax_url,
                type: 'POST',
                data: {
                    action: 'rp_filter_products',
                    category_id: this.currentCategory,
                    search_term: this.currentSearch,
                    sort: this.currentSort,
                    page: this.currentPage,
                    nonce: rp_ajax.nonce
                },
                success: (response) => {
                    if (response.success) {
                        if (append) {
                            $productsGrid.append(response.data.html);
                        } else {
                            $productsGrid.html(response.data.html);
                        }
                        
                        this.updatePagination(response.data);
                        this.animateProducts(append);
                        
                        if (!append) {
                            this.updateCategoryCounts(response.data);
                        }
                    } else {
                        this.showError(response.data);
                    }
                },
                error: () => {
                    this.showError(rp_ajax.error_text);
                },
                complete: () => {
                    this.isLoading = false;
                    $productsGrid.removeClass('rp-loading');
                    $('.rp-load-more-button').prop('disabled', false).removeClass('rp-loading');
                }
            });
        },

        /**
         * Update pagination controls
         */
        updatePagination: function(data) {
            const $loadMoreContainer = $('.rp-load-more-container');
            
            this.hasMore = this.currentPage < data.max_pages;
            
            if (this.hasMore && data.count > 0) {
                $loadMoreContainer.removeClass('rp-hidden');
            } else {
                $loadMoreContainer.addClass('rp-hidden');
            }
            
            // Update results count
            this.updateResultsCount(data.total);
        },

        /**
         * Update results count
         */
        updateResultsCount: function(total) {
            let $resultsCount = $('.rp-results-count');
            
            if ($resultsCount.length === 0) {
                $resultsCount = $(`<div class="rp-results-count"></div>`);
                $('.rp-menu-controls').append($resultsCount);
            }
            
            if (total > 0) {
                $resultsCount.text(`تعداد نتایج: ${total}`);
            } else {
                $resultsCount.text('نتیجه‌ای یافت نشد');
            }
        },

        /**
         * Update category counts
         */
        updateCategoryCounts: function(data) {
            // This would typically update category counts based on search results
            // For now, we'll just update the "All" category count
            if (this.currentSearch === '' && this.currentCategory === 0) {
                $('.rp-filter-all .rp-category-count').text(data.total);
            }
        },

        /**
         * Animate products when they enter viewport
         */
        animateProducts: function(append = false) {
            if ('IntersectionObserver' in window) {
                const productObserver = new IntersectionObserver((entries) => {
                    entries.forEach(entry => {
                        if (entry.isIntersecting) {
                            $(entry.target).addClass('rp-animated');
                            productObserver.unobserve(entry.target);
                        }
                    });
                }, {
                    threshold: 0.1,
                    rootMargin: '0px 0px -50px 0px'
                });
                
                const $products = $('.rp-product-card:not(.rp-animated)');
                $products.each(function() {
                    productObserver.observe(this);
                });
            } else {
                // Fallback: animate all products immediately
                $('.rp-product-card').addClass('rp-animated');
            }
            
            // Scroll to top if not appending
            if (!append && this.currentPage === 1) {
                const $menuSection = $('.rp-menu-section');
                if ($menuSection.length) {
                    const headerHeight = $('.rp-header').outerHeight() || 0;
                    $('html, body').animate({
                        scrollTop: $menuSection.offset().top - headerHeight - 20
                    }, 500);
                }
            }
        },

        /**
         * Show error message
         */
        showError: function(message) {
            const $productsGrid = $('.rp-products-grid');
            $productsGrid.html(`
                <div class="rp-ajax-error">
                    <i class="fas fa-exclamation-triangle"></i>
                    <h3>خطا در بارگذاری</h3>
                    <p>${message}</p>
                    <button class="rp-retry-button rp-menu-button">تلاش مجدد</button>
                </div>
            `);
            
            $('.rp-retry-button').on('click', () => {
                this.loadProducts();
            });
        },

        /**
         * Debounce function for performance
         */
        debounce: function(func, wait) {
            let timeout;
            return function executedFunction(...args) {
                const later = () => {
                    clearTimeout(timeout);
                    func(...args);
                };
                clearTimeout(timeout);
                timeout = setTimeout(later, wait);
            };
        }
    };

    /**
     * Initialize when document is ready
     */
    $(document).ready(function() {
        AjaxMenu.init();
    });

    /**
     * Make AjaxMenu available globally
     */
    window.AjaxMenu = AjaxMenu;

})(jQuery);