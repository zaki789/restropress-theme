<?php
/**
 * The template for displaying pages
 *
 * @package RestroPress
 * @version 1.0.0
 */

get_header();
?>

<div class="rp-container">
    <div class="rp-content-area">
        <article id="post-<?php the_ID(); ?>" <?php post_class('rp-page'); ?>>
            <header class="rp-page-header">
                <h1 class="rp-page-title"><?php the_title(); ?></h1>
                
                <?php if (has_post_thumbnail()) : ?>
                    <div class="rp-page-thumbnail">
                        <?php the_post_thumbnail('large'); ?>
                    </div>
                <?php endif; ?>
            </header>
            
            <div class="rp-page-content">
                <?php
                the_content();
                
                wp_link_pages(array(
                    'before' => '<div class="rp-page-links">' . __('صفحات:', 'restropress'),
                    'after'  => '</div>',
                ));
                ?>
            </div>
            
            <?php if (get_edit_post_link()) : ?>
                <footer class="rp-page-footer">
                    <?php
                    edit_post_link(
                        sprintf(
                            __('ویرایش <span class="screen-reader-text">%s</span>', 'restropress'),
                            get_the_title()
                        ),
                        '<span class="edit-link">',
                        '</span>'
                    );
                    ?>
                </footer>
            <?php endif; ?>
        </article>
        
        <?php
        // If comments are open or we have at least one comment, load up the comment template.
        if (comments_open() || get_comments_number()) :
            comments_template();
        endif;
        ?>
    </div>
    
    <?php if (is_active_sidebar('main-sidebar')) : ?>
        <aside class="rp-sidebar">
            <?php dynamic_sidebar('main-sidebar'); ?>
        </aside>
    <?php endif; ?>
</div>

<?php
get_footer();