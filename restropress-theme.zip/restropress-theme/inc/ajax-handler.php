<?php
/**
 * AJAX handlers for RestroPress theme
 *
 * @package RestroPress
 * @version 1.0.0
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Enhanced AJAX product filter with categories and search
 */
function restropress_ajax_filter_products() {
    // Verify nonce
    if (!wp_verify_nonce($_POST['nonce'], 'rp_nonce')) {
        wp_send_json_error('Nonce verification failed');
    }

    $category_id = isset($_POST['category_id']) ? intval($_POST['category_id']) : 0;
    $search_term = isset($_POST['search_term']) ? sanitize_text_field($_POST['search_term']) : '';
    $page = isset($_POST['page']) ? intval($_POST['page']) : 1;
    $posts_per_page = isset($_POST['posts_per_page']) ? intval($_POST['posts_per_page']) : 12;

    $args = array(
        'post_type' => 'product',
        'posts_per_page' => $posts_per_page,
        'paged' => $page,
        'post_status' => 'publish',
        'meta_query' => array(
            array(
                'key' => '_visibility',
                'value' => array('visible', 'catalog'),
                'compare' => 'IN'
            )
        )
    );

    // Add category filter
    if ($category_id > 0) {
        $args['tax_query'] = array(
            array(
                'taxonomy' => 'product_cat',
                'field' => 'term_id',
                'terms' => $category_id
            )
        );
    }

    // Add search filter
    if (!empty($search_term)) {
        $args['s'] = $search_term;
    }

    // Add meta query for featured products if needed
    if (isset($_POST['featured']) && $_POST['featured'] === 'true') {
        $args['tax_query'][] = array(
            'taxonomy' => 'product_visibility',
            'field' => 'name',
            'terms' => 'featured',
        );
    }

    $products = new WP_Query($args);

    ob_start();

    if ($products->have_posts()) {
        echo '<div class="rp-products-grid">';
        
        while ($products->have_posts()) {
            $products->the_post();
            global $product;
            
            // Get product data
            $product_id = get_the_ID();
            $product_title = get_the_title();
            $product_excerpt = get_the_excerpt();
            $product_price = $product->get_price_html();
            $product_image = get_the_post_thumbnail_url($product_id, 'rp-product-thumb');
            $product_url = get_permalink();
            $in_stock = $product->is_in_stock();
            $is_featured = $product->is_featured();
            ?>
            
            <div class="rp-product-card" data-product-id="<?php echo $product_id; ?>">
                <?php if ($is_featured) : ?>
                    <div class="rp-product-badge rp-featured-badge">
                        <i class="fas fa-star"></i>
                        <?php _e('پیشنهاد ویژه', 'restropress'); ?>
                    </div>
                <?php endif; ?>
                
                <?php if (!$in_stock) : ?>
                    <div class="rp-product-badge rp-outofstock-badge">
                        <?php _e('ناموجود', 'restropress'); ?>
                    </div>
                <?php endif; ?>
                
                <?php if ($product_image) : ?>
                    <img src="<?php echo esc_url($product_image); ?>" alt="<?php echo esc_attr($product_title); ?>" class="rp-product-image">
                <?php else : ?>
                    <div class="rp-product-image-placeholder">
                        <i class="fas fa-utensils"></i>
                    </div>
                <?php endif; ?>
                
                <div class="rp-product-info">
                    <h3 class="rp-product-title"><?php echo esc_html($product_title); ?></h3>
                    
                    <?php if ($product_excerpt) : ?>
                        <p class="rp-product-description"><?php echo wp_trim_words($product_excerpt, 15); ?></p>
                    <?php endif; ?>
                    
                    <div class="rp-product-meta">
                        <?php if ($product->get_regular_price() && $product->get_sale_price()) : ?>
                            <div class="rp-product-price">
                                <span class="rp-sale-price"><?php echo wc_price($product->get_sale_price()); ?></span>
                                <span class="rp-regular-price"><?php echo wc_price($product->get_regular_price()); ?></span>
                            </div>
                        <?php else : ?>
                            <div class="rp-product-price">
                                <?php echo $product_price; ?>
                            </div>
                        <?php endif; ?>
                        
                        <?php if ($product->get_average_rating() > 0) : ?>
                            <div class="rp-product-rating">
                                <div class="rp-star-rating">
                                    <?php
                                    $rating = $product->get_average_rating();
                                    for ($i = 1; $i <= 5; $i++) {
                                        if ($i <= $rating) {
                                            echo '<i class="fas fa-star"></i>';
                                        } elseif ($i - 0.5 <= $rating) {
                                            echo '<i class="fas fa-star-half-alt"></i>';
                                        } else {
                                            echo '<i class="far fa-star"></i>';
                                        }
                                    }
                                    ?>
                                </div>
                                <span class="rp-rating-count">(<?php echo $product->get_rating_count(); ?>)</span>
                            </div>
                        <?php endif; ?>
                    </div>
                    
                    <div class="rp-product-actions">
                        <?php if ($in_stock) : ?>
                            <button class="rp-add-to-cart" data-product-id="<?php echo $product_id; ?>" data-product-name="<?php echo esc_attr($product_title); ?>">
                                <i class="fas fa-shopping-cart"></i>
                                <span class="rp-button-text"><?php _e('افزودن به سبد', 'restropress'); ?></span>
                                <span class="rp-loading-spinner"></span>
                            </button>
                            
                            <div class="rp-quantity-selector rp-hidden">
                                <button class="rp-quantity-minus" type="button">-</button>
                                <input type="number" class="rp-quantity-input" value="1" min="1" max="10">
                                <button class="rp-quantity-plus" type="button">+</button>
                            </div>
                        <?php else : ?>
                            <button class="rp-add-to-cart rp-disabled" disabled>
                                <i class="fas fa-times"></i>
                                <?php _e('ناموجود', 'restropress'); ?>
                            </button>
                        <?php endif; ?>
                        
                        <button class="rp-quick-view" data-product-id="<?php echo $product_id; ?>">
                            <i class="fas fa-eye"></i>
                        </button>
                    </div>
                </div>
            </div>
            <?php
        }
        
        echo '</div>';
        
        // Pagination
        if ($products->max_num_pages > 1) {
            echo '<div class="rp-ajax-pagination">';
            echo '<div class="rp-pagination-info">';
            printf(
                __('نمایش %d از %d محصول', 'restropress'),
                $products->post_count,
                $products->found_posts
            );
            echo '</div>';
            
            echo '<div class="rp-pagination-links">';
            if ($page > 1) {
                echo '<button class="rp-pagination-prev" data-page="' . ($page - 1) . '">';
                echo '<i class="fas fa-chevron-right"></i>';
                echo __('صفحه قبلی', 'restropress');
                echo '</button>';
            }
            
            if ($page < $products->max_num_pages) {
                echo '<button class="rp-pagination-next" data-page="' . ($page + 1) . '">';
                echo __('صفحه بعدی', 'restropress');
                echo '<i class="fas fa-chevron-left"></i>';
                echo '</button>';
            }
            echo '</div>';
            echo '</div>';
        }
        
    } else {
        echo '<div class="rp-no-products rp-text-center">';
        echo '<i class="fas fa-search" style="font-size: 3rem; color: #ccc; margin-bottom: 1rem;"></i>';
        echo '<h3>' . __('محصولی یافت نشد', 'restropress') . '</h3>';
        echo '<p>' . __('متاسفانه هیچ محصولی مطابق با فیلترهای شما یافت نشد.', 'restropress') . '</p>';
        
        if (!empty($search_term) || $category_id > 0) {
            echo '<button class="rp-reset-filters rp-menu-button">' . __('حذف فیلترها', 'restropress') . '</button>';
        }
        echo '</div>';
    }

    $output = ob_get_clean();
    
    $response = array(
        'success' => true,
        'html' => $output,
        'count' => $products->post_count,
        'total' => $products->found_posts,
        'max_pages' => $products->max_num_pages
    );
    
    wp_send_json_success($response);
    wp_die();
}
add_action('wp_ajax_rp_filter_products', 'restropress_ajax_filter_products');
add_action('wp_ajax_nopriv_rp_filter_products', 'restropress_ajax_filter_products');

/**
 * Enhanced AJAX add to cart with quantity support
 */
function restropress_ajax_add_to_cart() {
    // Verify nonce
    if (!wp_verify_nonce($_POST['nonce'], 'rp_nonce')) {
        wp_send_json_error('Nonce verification failed');
    }

    $product_id = isset($_POST['product_id']) ? intval($_POST['product_id']) : 0;
    $quantity = isset($_POST['quantity']) ? intval($_POST['quantity']) : 1;
    $variation_id = isset($_POST['variation_id']) ? intval($_POST['variation_id']) : 0;
    $variation = isset($_POST['variation']) ? $_POST['variation'] : array();

    if ($product_id === 0) {
        wp_send_json_error(__('محصول معتبر نیست.', 'restropress'));
    }

    // Check if WooCommerce is active
    if (!class_exists('WooCommerce')) {
        wp_send_json_error(__('ووکامرس فعال نیست.', 'restropress'));
    }

    // Check if product is purchasable and in stock
    $product = wc_get_product($product_id);
    if (!$product) {
        wp_send_json_error(__('محصول یافت نشد.', 'restropress'));
    }

    if (!$product->is_purchasable()) {
        wp_send_json_error(__('این محصول قابل خریداری نیست.', 'restropress'));
    }

    if (!$product->is_in_stock()) {
        wp_send_json_error(__('این محصول در انبار موجود نیست.', 'restropress'));
    }

    // Check quantity
    if ($quantity <= 0) {
        wp_send_json_error(__('تعداد نامعتبر است.', 'restropress'));
    }

    // Add to cart
    if ($variation_id > 0) {
        $cart_item_key = WC()->cart->add_to_cart($product_id, $quantity, $variation_id, $variation);
    } else {
        $cart_item_key = WC()->cart->add_to_cart($product_id, $quantity);
    }

    if ($cart_item_key) {
        // Get cart fragments for update
        $fragments = array();
        
        // Cart count
        $fragments['.rp-cart-count'] = '<span class="rp-cart-count">' . WC()->cart->get_cart_contents_count() . '</span>';
        
        // Cart total
        $fragments['.rp-cart-total'] = '<span class="rp-cart-total">' . WC()->cart->get_cart_total() . '</span>';
        
        // Mini cart content
        ob_start();
        restropress_mini_cart_content();
        $fragments['.rp-mini-cart-content'] = ob_get_clean();

        $response = array(
            'success' => true,
            'message' => __('محصول به سبد خرید اضافه شد.', 'restropress'),
            'cart_count' => WC()->cart->get_cart_contents_count(),
            'cart_total' => WC()->cart->get_cart_total(),
            'cart_item_key' => $cart_item_key,
            'fragments' => $fragments
        );
        
        wp_send_json_success($response);
    } else {
        $error_message = __('خطا در افزودن به سبد خرید.', 'restropress');
        
        // Get specific error if available
        if (wc_notice_count('error') > 0) {
            $messages = wc_get_notices('error');
            if (!empty($messages)) {
                $error_message = $messages[0]['notice'];
            }
        }
        
        wp_send_json_error($error_message);
    }
    
    wp_die();
}
add_action('wp_ajax_rp_add_to_cart', 'restropress_ajax_add_to_cart');
add_action('wp_ajax_nopriv_rp_add_to_cart', 'restropress_ajax_add_to_cart');

/**
 * AJAX update cart item quantity
 */
function restropress_ajax_update_cart_quantity() {
    // Verify nonce
    if (!wp_verify_nonce($_POST['nonce'], 'rp_nonce')) {
        wp_send_json_error('Nonce verification failed');
    }

    $cart_item_key = isset($_POST['cart_item_key']) ? sanitize_text_field($_POST['cart_item_key']) : '';
    $quantity = isset($_POST['quantity']) ? intval($_POST['quantity']) : 0;

    if (empty($cart_item_key)) {
        wp_send_json_error(__('کلید سبد خرید نامعتبر است.', 'restropress'));
    }

    if ($quantity <= 0) {
        // Remove item if quantity is 0
        $result = WC()->cart->remove_cart_item($cart_item_key);
        $action = 'removed';
    } else {
        // Update quantity
        $result = WC()->cart->set_quantity($cart_item_key, $quantity);
        $action = 'updated';
    }

    if ($result) {
        $fragments = array();
        
        // Cart count
        $fragments['.rp-cart-count'] = '<span class="rp-cart-count">' . WC()->cart->get_cart_contents_count() . '</span>';
        
        // Cart total
        $fragments['.rp-cart-total'] = '<span class="rp-cart-total">' . WC()->cart->get_cart_total() . '</span>';
        
        // Mini cart content
        ob_start();
        restropress_mini_cart_content();
        $fragments['.rp-mini-cart-content'] = ob_get_clean();

        $response = array(
            'success' => true,
            'message' => $action === 'removed' ? __('محصول از سبد خرید حذف شد.', 'restropress') : __('تعداد محصول بروزرسانی شد.', 'restropress'),
            'cart_count' => WC()->cart->get_cart_contents_count(),
            'cart_total' => WC()->cart->get_cart_total(),
            'fragments' => $fragments
        );
        
        wp_send_json_success($response);
    } else {
        wp_send_json_error(__('خطا در بروزرسانی سبد خرید.', 'restropress'));
    }
    
    wp_die();
}
add_action('wp_ajax_rp_update_cart_quantity', 'restropress_ajax_update_cart_quantity');
add_action('wp_ajax_nopriv_rp_update_cart_quantity', 'restropress_ajax_update_cart_quantity');

/**
 * AJAX quick view product
 */
function restropress_ajax_quick_view() {
    // Verify nonce
    if (!wp_verify_nonce($_POST['nonce'], 'rp_nonce')) {
        wp_send_json_error('Nonce verification failed');
    }

    $product_id = isset($_POST['product_id']) ? intval($_POST['product_id']) : 0;

    if ($product_id === 0) {
        wp_send_json_error(__('محصول معتبر نیست.', 'restropress'));
    }

    $product = wc_get_product($product_id);

    if (!$product) {
        wp_send_json_error(__('محصول یافت نشد.', 'restropress'));
    }

    ob_start();
    ?>
    <div class="rp-quick-view-modal">
        <div class="rp-quick-view-content">
            <button class="rp-quick-view-close">
                <i class="fas fa-times"></i>
            </button>
            
            <div class="rp-quick-view-images">
                <?php
                $image_ids = $product->get_gallery_image_ids();
                array_unshift($image_ids, $product->get_image_id());
                
                if (!empty($image_ids)) {
                    echo '<div class="rp-quick-view-gallery">';
                    foreach ($image_ids as $image_id) {
                        if ($image_id) {
                            echo wp_get_attachment_image($image_id, 'large', false, array(
                                'class' => 'rp-quick-view-image'
                            ));
                        }
                    }
                    echo '</div>';
                }
                ?>
            </div>
            
            <div class="rp-quick-view-details">
                <h2 class="rp-quick-view-title"><?php echo $product->get_name(); ?></h2>
                
                <div class="rp-quick-view-price">
                    <?php echo $product->get_price_html(); ?>
                </div>
                
                <?php if ($product->get_rating_count() > 0) : ?>
                    <div class="rp-quick-view-rating">
                        <?php echo wc_get_rating_html($product->get_average_rating(), $product->get_rating_count()); ?>
                        <span class="rp-rating-count">(<?php echo $product->get_rating_count(); ?>)</span>
                    </div>
                <?php endif; ?>
                
                <div class="rp-quick-view-description">
                    <?php echo apply_filters('the_content', $product->get_short_description() ?: $product->get_description()); ?>
                </div>
                
                <div class="rp-quick-view-actions">
                    <?php if ($product->is_in_stock()) : ?>
                        <div class="rp-quantity-selector">
                            <button class="rp-quantity-minus" type="button">-</button>
                            <input type="number" class="rp-quantity-input" value="1" min="1" max="<?php echo $product->get_stock_quantity() ?: 10; ?>">
                            <button class="rp-quantity-plus" type="button">+</button>
                        </div>
                        
                        <button class="rp-add-to-cart rp-menu-button" data-product-id="<?php echo $product_id; ?>">
                            <i class="fas fa-shopping-cart"></i>
                            <?php _e('افزودن به سبد خرید', 'restropress'); ?>
                        </button>
                    <?php else : ?>
                        <button class="rp-add-to-cart rp-disabled" disabled>
                            <i class="fas fa-times"></i>
                            <?php _e('ناموجود', 'restropress'); ?>
                        </button>
                    <?php endif; ?>
                </div>
                
                <div class="rp-quick-view-meta">
                    <?php if ($product->get_sku()) : ?>
                        <div class="rp-meta-item">
                            <strong><?php _e('کد محصول:', 'restropress'); ?></strong>
                            <span><?php echo $product->get_sku(); ?></span>
                        </div>
                    <?php endif; ?>
                    
                    <div class="rp-meta-item">
                        <strong><?php _e('دسته‌بندی:', 'restropress'); ?></strong>
                        <span><?php echo wc_get_product_category_list($product_id); ?></span>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php
    $output = ob_get_clean();

    wp_send_json_success(array(
        'html' => $output
    ));
    
    wp_die();
}
add_action('wp_ajax_rp_quick_view', 'restropress_ajax_quick_view');
add_action('wp_ajax_nopriv_rp_quick_view', 'restropress_ajax_quick_view');

/**
 * Mini cart content for fragments
 */
function restropress_mini_cart_content() {
    ?>
    <div class="rp-mini-cart-content">
        <?php if (!WC()->cart->is_empty()) : ?>
            <div class="rp-mini-cart-items">
                <?php foreach (WC()->cart->get_cart() as $cart_item_key => $cart_item) : ?>
                    <?php
                    $_product = apply_filters('woocommerce_cart_item_product', $cart_item['data'], $cart_item, $cart_item_key);
                    $product_id = apply_filters('woocommerce_cart_item_product_id', $cart_item['product_id'], $cart_item, $cart_item_key);
                    ?>
                    
                    <div class="rp-mini-cart-item" data-cart-item-key="<?php echo $cart_item_key; ?>">
                        <div class="rp-mini-cart-item-image">
                            <?php echo $_product->get_image('thumbnail'); ?>
                        </div>
                        
                        <div class="rp-mini-cart-item-details">
                            <h4 class="rp-mini-cart-item-title"><?php echo $_product->get_name(); ?></h4>
                            <div class="rp-mini-cart-item-price">
                                <?php echo WC()->cart->get_product_price($_product); ?>
                            </div>
                            <div class="rp-mini-cart-item-quantity">
                                <button class="rp-mini-cart-quantity-minus" data-cart-item-key="<?php echo $cart_item_key; ?>">-</button>
                                <span class="rp-mini-cart-quantity-value"><?php echo $cart_item['quantity']; ?></span>
                                <button class="rp-mini-cart-quantity-plus" data-cart-item-key="<?php echo $cart_item_key; ?>">+</button>
                            </div>
                        </div>
                        
                        <button class="rp-mini-cart-item-remove" data-cart-item-key="<?php echo $cart_item_key; ?>">
                            <i class="fas fa-times"></i>
                        </button>
                    </div>
                <?php endforeach; ?>
            </div>
            
            <div class="rp-mini-cart-footer">
                <div class="rp-mini-cart-total">
                    <strong><?php _e('جمع کل:', 'restropress'); ?></strong>
                    <span class="rp-cart-total"><?php echo WC()->cart->get_cart_total(); ?></span>
                </div>
                
                <div class="rp-mini-cart-actions">
                    <a href="<?php echo wc_get_cart_url(); ?>" class="rp-view-cart">
                        <?php _e('مشاهده سبد خرید', 'restropress'); ?>
                    </a>
                    <a href="<?php echo wc_get_checkout_url(); ?>" class="rp-checkout">
                        <?php _e('تسویه حساب', 'restropress'); ?>
                    </a>
                </div>
            </div>
        <?php else : ?>
            <div class="rp-mini-cart-empty">
                <i class="fas fa-shopping-cart"></i>
                <p><?php _e('سبد خرید شما خالی است', 'restropress'); ?></p>
            </div>
        <?php endif; ?>
    </div>
    <?php
}

/**
 * Get product categories for filter
 */
function restropress_ajax_get_categories() {
    $categories = get_terms(array(
        'taxonomy' => 'product_cat',
        'hide_empty' => true,
        'parent' => 0
    ));

    $categories_data = array();

    if (!empty($categories) && !is_wp_error($categories)) {
        foreach ($categories as $category) {
            $categories_data[] = array(
                'id' => $category->term_id,
                'name' => $category->name,
                'slug' => $category->slug,
                'count' => $category->count,
                'image' => get_term_meta($category->term_id, 'thumbnail_id', true)
            );
        }
    }

    wp_send_json_success($categories_data);
    wp_die();
}
add_action('wp_ajax_rp_get_categories', 'restropress_ajax_get_categories');
add_action('wp_ajax_nopriv_rp_get_categories', 'restropress_ajax_get_categories');