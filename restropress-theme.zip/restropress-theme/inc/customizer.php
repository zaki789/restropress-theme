<?php
/**
 * Customizer settings for RestroPress theme
 *
 * @package RestroPress
 * @version 1.0.0
 */

function restropress_customize_register($wp_customize) {
    
    // Main Panel
    $wp_customize->add_panel('restropress_settings', array(
        'title' => __('تنظیمات RestroPress', 'restropress'),
        'priority' => 30,
    ));
    
    // Colors Section
    $wp_customize->add_section('rp_colors', array(
        'title' => __('رنگ ها', 'restropress'),
        'panel' => 'restropress_settings',
        'priority' => 10,
    ));
    
    // Fonts Section
    $wp_customize->add_section('rp_fonts', array(
        'title' => __('فونت ها', 'restropress'),
        'panel' => 'restropress_settings',
        'priority' => 20,
    ));
    
    // Header Section
    $wp_customize->add_section('rp_header', array(
        'title' => __('هدر', 'restropress'),
        'panel' => 'restropress_settings',
        'priority' => 30,
    ));
    
    // Hero Section
    $wp_customize->add_section('rp_hero', array(
        'title' => __('بخش اصلی (Hero)', 'restropress'),
        'panel' => 'restropress_settings',
        'priority' => 40,
    ));
    
    // Footer Section
    $wp_customize->add_section('rp_footer', array(
        'title' => __('فوتر', 'restropress'),
        'panel' => 'restropress_settings',
        'priority' => 50,
    ));
    
    // ========== Color Controls ==========
    
    // Primary Color
    $wp_customize->add_setting('rp_primary_color', array(
        'default' => '#c8a97e',
        'sanitize_callback' => 'sanitize_hex_color',
        'transport' => 'postMessage'
    ));
    
    $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'rp_primary_color', array(
        'label' => __('رنگ اصلی', 'restropress'),
        'section' => 'rp_colors',
        'description' => __('رنگ اصلی قالب برای دکمه‌ها و المان‌های مهم', 'restropress')
    )));
    
    // Secondary Color
    $wp_customize->add_setting('rp_secondary_color', array(
        'default' => '#1a1a1a',
        'sanitize_callback' => 'sanitize_hex_color',
        'transport' => 'postMessage'
    ));
    
    $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'rp_secondary_color', array(
        'label' => __('رنگ ثانویه', 'restropress'),
        'section' => 'rp_colors',
        'description' => __('رنگ برای هدر و المان‌های ثانویه', 'restropress')
    )));
    
    // Accent Color
    $wp_customize->add_setting('rp_accent_color', array(
        'default' => '#d4af37',
        'sanitize_callback' => 'sanitize_hex_color',
        'transport' => 'postMessage'
    ));
    
    $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'rp_accent_color', array(
        'label' => __('رنگ اکسان', 'restropress'),
        'section' => 'rp_colors',
        'description' => __('رنگ برای هایلایت و تاکید', 'restropress')
    )));
    
    // ========== Font Controls ==========
    
    // Primary Font
    $wp_customize->add_setting('rp_primary_font', array(
        'default' => 'Playfair Display',
        'sanitize_callback' => 'restropress_sanitize_font_choice',
        'transport' => 'postMessage'
    ));
    
    $wp_customize->add_control('rp_primary_font', array(
        'label' => __('فونت اصلی', 'restropress'),
        'section' => 'rp_fonts',
        'type' => 'select',
        'choices' => array(
            'Playfair Display' => 'Playfair Display',
            'Dancing Script' => 'Dancing Script',
            'Cormorant Garamond' => 'Cormorant Garamond',
            'Vazirmatn' => 'Vazirmatn (فارسی)',
            'Arial' => 'Arial',
            'Tahoma' => 'Tahoma',
        ),
        'description' => __('فونت برای عناوین و تیترها', 'restropress')
    ));
    
    // Secondary Font
    $wp_customize->add_setting('rp_secondary_font', array(
        'default' => 'Open Sans',
        'sanitize_callback' => 'restropress_sanitize_font_choice',
        'transport' => 'postMessage'
    ));
    
    $wp_customize->add_control('rp_secondary_font', array(
        'label' => __('فونت ثانویه', 'restropress'),
        'section' => 'rp_fonts',
        'type' => 'select',
        'choices' => array(
            'Open Sans' => 'Open Sans',
            'Roboto' => 'Roboto',
            'Lato' => 'Lato',
            'Vazirmatn' => 'Vazirmatn (فارسی)',
            'Arial' => 'Arial',
            'Tahoma' => 'Tahoma',
        ),
        'description' => __('فونت برای ناوبری و دکمه‌ها', 'restropress')
    ));
    
    // Body Font
    $wp_customize->add_setting('rp_body_font', array(
        'default' => 'Roboto',
        'sanitize_callback' => 'restropress_sanitize_font_choice',
        'transport' => 'postMessage'
    ));
    
    $wp_customize->add_control('rp_body_font', array(
        'label' => __('فونت بدنه', 'restropress'),
        'section' => 'rp_fonts',
        'type' => 'select',
        'choices' => array(
            'Roboto' => 'Roboto',
            'Open Sans' => 'Open Sans',
            'Vazirmatn' => 'Vazirmatn (فارسی)',
            'Arial' => 'Arial',
            'Tahoma' => 'Tahoma',
        ),
        'description' => __('فونت برای متن‌های اصلی', 'restropress')
    ));
    
    // ========== Header Controls ==========
    
    // Logo
    $wp_customize->add_setting('rp_logo', array(
        'default' => '',
        'sanitize_callback' => 'esc_url_raw'
    ));
    
    $wp_customize->add_control(new WP_Customize_Image_Control($wp_customize, 'rp_logo', array(
        'label' => __('لوگو', 'restropress'),
        'section' => 'rp_header',
        'description' => __('آپلود لوگوی خود (سایز پیشنهادی: 200x80 پیکسل)', 'restropress')
    )));
    
    // ========== Hero Controls ==========
    
    // Hero Background Type
    $wp_customize->add_setting('rp_hero_bg_type', array(
        'default' => 'image',
        'sanitize_callback' => 'restropress_sanitize_bg_type'
    ));
    
    $wp_customize->add_control('rp_hero_bg_type', array(
        'label' => __('نوع پس زمینه', 'restropress'),
        'section' => 'rp_hero',
        'type' => 'radio',
        'choices' => array(
            'image' => __('تصویر', 'restropress'),
            'color' => __('رنگ', 'restropress'),
        ),
    ));
    
    // Hero Background Image
    $wp_customize->add_setting('rp_hero_bg_image', array(
        'default' => '',
        'sanitize_callback' => 'esc_url_raw'
    ));
    
    $wp_customize->add_control(new WP_Customize_Image_Control($wp_customize, 'rp_hero_bg_image', array(
        'label' => __('تصویر پس زمینه', 'restropress'),
        'section' => 'rp_hero',
        'active_callback' => 'restropress_is_hero_bg_image'
    )));
    
    // Hero Background Color
    $wp_customize->add_setting('rp_hero_bg_color', array(
        'default' => '#1a1a1a',
        'sanitize_callback' => 'sanitize_hex_color'
    ));
    
    $wp_customize->add_control(new WP_Customize_Color_Control($wp_customize, 'rp_hero_bg_color', array(
        'label' => __('رنگ پس زمینه', 'restropress'),
        'section' => 'rp_hero',
        'active_callback' => 'restropress_is_hero_bg_color'
    )));
    
    // Hero Title
    $wp_customize->add_setting('rp_hero_title', array(
        'default' => '',
        'sanitize_callback' => 'sanitize_text_field'
    ));
    
    $wp_customize->add_control('rp_hero_title', array(
        'label' => __('عنوان بخش اصلی', 'restropress'),
        'section' => 'rp_hero',
        'type' => 'text',
        'description' => __('اگر خالی باشد، نام سایت نمایش داده می‌شود', 'restropress')
    ));
    
    // Hero Subtitle
    $wp_customize->add_setting('rp_hero_subtitle', array(
        'default' => '',
        'sanitize_callback' => 'sanitize_textarea_field'
    ));
    
    $wp_customize->add_control('rp_hero_subtitle', array(
        'label' => __('زیرعنوان بخش اصلی', 'restropress'),
        'section' => 'rp_hero',
        'type' => 'textarea',
        'description' => __('اگر خالی باشد، توضیح سایت نمایش داده می‌شود', 'restropress')
    ));
    
    // Hero Button Action
    $wp_customize->add_setting('rp_hero_button_action', array(
        'default' => 'scroll',
        'sanitize_callback' => 'restropress_sanitize_button_action'
    ));
    
    $wp_customize->add_control('rp_hero_button_action', array(
        'label' => __('عملکرد دکمه مشاهده منو', 'restropress'),
        'section' => 'rp_hero',
        'type' => 'select',
        'choices' => array(
            'scroll' => __('اسکرول به بخش منو', 'restropress'),
            'page' => __('باز کردن صفحه جدید', 'restropress'),
        ),
    ));
    
    // Hero Button Text
    $wp_customize->add_setting('rp_hero_button_text', array(
        'default' => 'مشاهده منو',
        'sanitize_callback' => 'sanitize_text_field'
    ));
    
    $wp_customize->add_control('rp_hero_button_text', array(
        'label' => __('متن دکمه', 'restropress'),
        'section' => 'rp_hero',
        'type' => 'text',
    ));
    
    // ========== Footer Controls ==========
    
    // Footer Address
    $wp_customize->add_setting('rp_footer_address', array(
        'default' => '',
        'sanitize_callback' => 'sanitize_textarea_field'
    ));
    
    $wp_customize->add_control('rp_footer_address', array(
        'label' => __('آدرس', 'restropress'),
        'section' => 'rp_footer',
        'type' => 'textarea',
    ));
    
    // Footer Phone
    $wp_customize->add_setting('rp_footer_phone', array(
        'default' => '',
        'sanitize_callback' => 'sanitize_text_field'
    ));
    
    $wp_customize->add_control('rp_footer_phone', array(
        'label' => __('شماره تماس', 'restropress'),
        'section' => 'rp_footer',
        'type' => 'text',
    ));
    
    // Footer Email
    $wp_customize->add_setting('rp_footer_email', array(
        'default' => '',
        'sanitize_callback' => 'sanitize_email'
    ));
    
    $wp_customize->add_control('rp_footer_email', array(
        'label' => __('ایمیل', 'restropress'),
        'section' => 'rp_footer',
        'type' => 'email',
    ));
    
    // Footer Instagram
    $wp_customize->add_setting('rp_footer_instagram', array(
        'default' => '',
        'sanitize_callback' => 'esc_url_raw'
    ));
    
    $wp_customize->add_control('rp_footer_instagram', array(
        'label' => __('آدرس اینستاگرام', 'restropress'),
        'section' => 'rp_footer',
        'type' => 'url',
    ));
    
    // Footer WhatsApp
    $wp_customize->add_setting('rp_footer_whatsapp', array(
        'default' => '',
        'sanitize_callback' => 'esc_url_raw'
    ));
    
    $wp_customize->add_control('rp_footer_whatsapp', array(
        'label' => __('لینک واتساپ', 'restropress'),
        'section' => 'rp_footer',
        'type' => 'url',
    ));
    
    // Business Hours
    $wp_customize->add_setting('rp_business_hours', array(
        'default' => '',
        'sanitize_callback' => 'sanitize_textarea_field'
    ));
    
    $wp_customize->add_control('rp_business_hours', array(
        'label' => __('ساعات کاری', 'restropress'),
        'section' => 'rp_footer',
        'type' => 'textarea',
        'description' => __('ساعات کاری رستوران یا کافه', 'restropress')
    ));
    
    // Footer Credit
    $wp_customize->add_setting('rp_footer_credit', array(
        'default' => '',
        'sanitize_callback' => 'sanitize_textarea_field'
    ));
    
    $wp_customize->add_control('rp_footer_credit', array(
        'label' => __('متن کپی رایت', 'restropress'),
        'section' => 'rp_footer',
        'type' => 'textarea',
        'description' => __('متن دلخواه برای بخش کپی رایت', 'restropress')
    ));
}

add_action('customize_register', 'restropress_customize_register');

/**
 * Sanitize font choice
 */
function restropress_sanitize_font_choice($input) {
    $valid = array(
        'Playfair Display', 'Dancing Script', 'Cormorant Garamond', 'Vazirmatn',
        'Open Sans', 'Roboto', 'Lato', 'Arial', 'Tahoma'
    );
    
    if (in_array($input, $valid)) {
        return $input;
    }
    
    return 'Playfair Display';
}

/**
 * Sanitize background type
 */
function restropress_sanitize_bg_type($input) {
    $valid = array('image', 'color');
    
    if (in_array($input, $valid)) {
        return $input;
    }
    
    return 'image';
}

/**
 * Sanitize button action
 */
function restropress_sanitize_button_action($input) {
    $valid = array('scroll', 'page');
    
    if (in_array($input, $valid)) {
        return $input;
    }
    
    return 'scroll';
}

/**
 * Check if hero background is image
 */
function restropress_is_hero_bg_image() {
    return get_theme_mod('rp_hero_bg_type', 'image') === 'image';
}

/**
 * Check if hero background is color
 */
function restropress_is_hero_bg_color() {
    return get_theme_mod('rp_hero_bg_type', 'image') === 'color';
}

/**
 * Add preview JS for live customizer
 */
function restropress_customize_preview_js() {
    wp_enqueue_script(
        'restropress-customizer-preview',
        RESTROPRESS_TEMPLATE_URL . '/assets/js/customizer-preview.js',
        array('jquery', 'customize-preview'),
        RESTROPRESS_VERSION,
        true
    );
}
add_action('customize_preview_init', 'restropress_customize_preview_js');