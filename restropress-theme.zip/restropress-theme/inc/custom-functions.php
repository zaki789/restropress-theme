<?php
/**
 * Custom functions for RestroPress theme
 *
 * @package RestroPress
 * @version 1.0.0
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Display hero section
 */
function restropress_display_hero_section() {
    $hero_title = rp_get_theme_mod('hero_title', '');
    $hero_subtitle = rp_get_theme_mod('hero_subtitle', '');
    $hero_button_text = rp_get_theme_mod('hero_button_text', 'مشاهده منو');
    $hero_button_action = rp_get_theme_mod('hero_button_action', 'scroll');
    
    // Use site info if custom texts are empty
    if (empty($hero_title)) {
        $hero_title = get_bloginfo('name');
    }
    
    if (empty($hero_subtitle)) {
        $hero_subtitle = get_bloginfo('description');
    }
    ?>
    <section class="rp-hero-section" style="--rp-hero-bg-image: <?php echo rp_get_hero_background(); ?>;">
        <div class="rp-hero-content">
            <h1 class="rp-hero-title"><?php echo esc_html($hero_title); ?></h1>
            <p class="rp-hero-subtitle"><?php echo esc_html($hero_subtitle); ?></p>
            
            <?php if ($hero_button_action === 'scroll') : ?>
                <a href="#rp-menu-section" class="rp-menu-button" data-action="scroll">
                    <?php echo esc_html($hero_button_text); ?>
                    <i class="fas fa-chevron-down"></i>
                </a>
            <?php else : ?>
                <?php
                $menu_page_id = rp_get_theme_mod('hero_menu_page');
                $menu_page_url = $menu_page_id ? get_permalink($menu_page_id) : wc_get_page_permalink('shop');
                ?>
                <a href="<?php echo esc_url($menu_page_url); ?>" class="rp-menu-button" data-action="page">
                    <?php echo esc_html($hero_button_text); ?>
                    <i class="fas fa-arrow-left"></i>
                </a>
            <?php endif; ?>
        </div>
    </section>
    <?php
}

/**
 * Display menu section with AJAX filtering
 */
function restropress_display_menu_section() {
    ?>
    <section id="rp-menu-section" class="rp-menu-section">
        <div class="rp-container">
            <h2 class="rp-section-title"><?php _e('منوی ما', 'restropress'); ?></h2>
            
            <!-- Search Box -->
            <div class="rp-menu-search">
                <div class="rp-search-box">
                    <input type="text" class="rp-search-input" placeholder="<?php _e('جستجو در منو...', 'restropress'); ?>">
                    <button class="rp-search-button">
                        <i class="fas fa-search"></i>
                    </button>
                </div>
            </div>
            
            <!-- Categories Filter -->
            <div class="rp-menu-categories">
                <?php rp_display_product_categories(); ?>
            </div>
            
            <!-- Products Grid -->
            <div class="rp-menu-content">
                <div class="rp-products-grid">
                    <?php
                    // Display initial products
                    $initial_products = new WP_Query(array(
                        'post_type' => 'product',
                        'posts_per_page' => 12,
                        'post_status' => 'publish'
                    ));
                    
                    if ($initial_products->have_posts()) {
                        while ($initial_products->have_posts()) {
                            $initial_products->the_post();
                            global $product;
                            ?>
                            <div class="rp-product-card">
                                <?php if (has_post_thumbnail()) : ?>
                                    <img src="<?php echo get_the_post_thumbnail_url(get_the_ID(), 'rp-product-thumb'); ?>" alt="<?php the_title(); ?>" class="rp-product-image">
                                <?php endif; ?>
                                
                                <div class="rp-product-info">
                                    <h3 class="rp-product-title"><?php the_title(); ?></h3>
                                    
                                    <?php if (get_the_excerpt()) : ?>
                                        <p class="rp-product-description"><?php echo wp_trim_words(get_the_excerpt(), 15); ?></p>
                                    <?php endif; ?>
                                    
                                    <div class="rp-product-price">
                                        <?php echo $product->get_price_html(); ?>
                                    </div>
                                    
                                    <button class="rp-add-to-cart" data-product-id="<?php echo get_the_ID(); ?>">
                                        <i class="fas fa-shopping-cart"></i>
                                        <?php _e('افزودن به سبد خرید', 'restropress'); ?>
                                    </button>
                                </div>
                            </div>
                            <?php
                        }
                        wp_reset_postdata();
                    }
                    ?>
                </div>
                
                <!-- Loading Indicator -->
                <div class="rp-loading-indicator rp-hidden">
                    <div class="rp-loading-spinner"></div>
                    <p><?php _e('در حال بارگذاری...', 'restropress'); ?></p>
                </div>
            </div>
        </div>
    </section>
    <?php
}

/**
 * Display featured products
 */
function restropress_display_featured_products($number = 6) {
    $featured_products = new WP_Query(array(
        'post_type' => 'product',
        'posts_per_page' => $number,
        'tax_query' => array(
            array(
                'taxonomy' => 'product_visibility',
                'field' => 'name',
                'terms' => 'featured',
            )
        )
    ));
    
    if ($featured_products->have_posts()) {
        ?>
        <section class="rp-featured-section">
            <div class="rp-container">
                <h2 class="rp-section-title"><?php _e('پیشنهادات ویژه', 'restropress'); ?></h2>
                
                <div class="rp-products-grid">
                    <?php
                    while ($featured_products->have_posts()) {
                        $featured_products->the_post();
                        global $product;
                        ?>
                        <div class="rp-product-card rp-featured-product">
                            <div class="rp-product-badge rp-featured-badge">
                                <i class="fas fa-star"></i>
                                <?php _e('ویژه', 'restropress'); ?>
                            </div>
                            
                            <?php if (has_post_thumbnail()) : ?>
                                <img src="<?php echo get_the_post_thumbnail_url(get_the_ID(), 'rp-product-thumb'); ?>" alt="<?php the_title(); ?>" class="rp-product-image">
                            <?php endif; ?>
                            
                            <div class="rp-product-info">
                                <h3 class="rp-product-title"><?php the_title(); ?></h3>
                                
                                <?php if (get_the_excerpt()) : ?>
                                    <p class="rp-product-description"><?php echo wp_trim_words(get_the_excerpt(), 15); ?></p>
                                <?php endif; ?>
                                
                                <div class="rp-product-price">
                                    <?php echo $product->get_price_html(); ?>
                                </div>
                                
                                <button class="rp-add-to-cart" data-product-id="<?php echo get_the_ID(); ?>">
                                    <i class="fas fa-shopping-cart"></i>
                                    <?php _e('افزودن به سبد خرید', 'restropress'); ?>
                                </button>
                            </div>
                        </div>
                        <?php
                    }
                    wp_reset_postdata();
                    ?>
                </div>
            </div>
        </section>
        <?php
    }
}

/**
 * Display testimonials section
 */
function restropress_display_testimonials() {
    $testimonials = array(
        array(
            'name' => 'علیرضا محمدی',
            'text' => 'بهترین قهوه شهر رو اینجا خوردم. فضای بسیار دلنشین و پرسنل خوش برخورد.',
            'rating' => 5
        ),
        array(
            'name' => 'فاطمه کریمی',
            'text' => 'کیک‌های خوشمزه و سرویس عالی. حتما دوباره میام.',
            'rating' => 4
        ),
        array(
            'name' => 'محمد حسینی',
            'text' => 'منوی متنوع و قیمت‌های مناسب. برای دورهمی عالیه.',
            'rating' => 5
        )
    );
    ?>
    <section class="rp-testimonials-section">
        <div class="rp-container">
            <h2 class="rp-section-title"><?php _e('نظرات مشتریان', 'restropress'); ?></h2>
            
            <div class="rp-testimonials-grid">
                <?php foreach ($testimonials as $testimonial) : ?>
                    <div class="rp-testimonial-card">
                        <div class="rp-testimonial-content">
                            <p>"<?php echo esc_html($testimonial['text']); ?>"</p>
                        </div>
                        
                        <div class="rp-testimonial-rating">
                            <?php
                            for ($i = 1; $i <= 5; $i++) {
                                if ($i <= $testimonial['rating']) {
                                    echo '<i class="fas fa-star"></i>';
                                } else {
                                    echo '<i class="far fa-star"></i>';
                                }
                            }
                            ?>
                        </div>
                        
                        <div class="rp-testimonial-author">
                            <strong><?php echo esc_html($testimonial['name']); ?></strong>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
    </section>
    <?php
}

/**
 * Display opening hours
 */
function restropress_display_opening_hours() {
    $opening_hours = rp_get_theme_mod('business_hours', '');
    ?>
    <section class="rp-hours-section">
        <div class="rp-container">
            <div class="rp-hours-content">
                <div class="rp-hours-info">
                    <h2><?php _e('ساعات کاری', 'restropress'); ?></h2>
                    
                    <?php if ($opening_hours) : ?>
                        <div class="rp-hours-text">
                            <?php echo wp_kses_post(wpautop($opening_hours)); ?>
                        </div>
                    <?php else : ?>
                        <div class="rp-hours-default">
                            <div class="rp-hour-item">
                                <span class="rp-day"><?php _e('شنبه - چهارشنبه', 'restropress'); ?></span>
                                <span class="rp-time">۸:۰۰ - ۲۴:۰۰</span>
                            </div>
                            <div class="rp-hour-item">
                                <span class="rp-day"><?php _e('پنجشنبه', 'restropress'); ?></span>
                                <span class="rp-time">۸:۰۰ - ۲۳:۰۰</span>
                            </div>
                            <div class="rp-hour-item">
                                <span class="rp-day"><?php _e('جمعه', 'restropress'); ?></span>
                                <span class="rp-time">۱۰:۰۰ - ۲۴:۰۰</span>
                            </div>
                        </div>
                    <?php endif; ?>
                    
                    <div class="rp-contact-cta">
                        <p><?php _e('برای رزرو میز با ما تماس بگیرید', 'restropress'); ?></p>
                        <?php
                        $phone = rp_get_theme_mod('footer_phone');
                        if ($phone) {
                            echo '<a href="tel:' . esc_attr($phone) . '" class="rp-phone-link">' . esc_html($phone) . '</a>';
                        }
                        ?>
                    </div>
                </div>
                
                <div class="rp-hours-image">
                    <div class="rp-image-placeholder">
                        <i class="fas fa-coffee"></i>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <?php
}

/**
 * Add custom CSS from customizer
 */
function restropress_custom_css() {
    $custom_css = rp_get_theme_mod('custom_css', '');
    
    if (!empty($custom_css)) {
        echo '<style type="text/css">' . wp_strip_all_tags($custom_css) . '</style>';
    }
}
add_action('wp_head', 'restropress_custom_css');

/**
 * Add custom JavaScript from customizer
 */
function restropress_custom_js() {
    $custom_js = rp_get_theme_mod('custom_js', '');
    
    if (!empty($custom_js)) {
        echo '<script type="text/javascript">' . wp_strip_all_tags($custom_js) . '</script>';
    }
}
add_action('wp_footer', 'restropress_custom_js');

/**
 * Get social media links
 */
function restropress_get_social_links() {
    return array(
        'instagram' => array(
            'url' => rp_get_theme_mod('footer_instagram'),
            'icon' => 'fab fa-instagram',
            'label' => 'اینستاگرام'
        ),
        'whatsapp' => array(
            'url' => rp_get_theme_mod('footer_whatsapp'),
            'icon' => 'fab fa-whatsapp',
            'label' => 'واتساپ'
        ),
        'telegram' => array(
            'url' => rp_get_theme_mod('footer_telegram'),
            'icon' => 'fab fa-telegram',
            'label' => 'تلگرام'
        ),
        'twitter' => array(
            'url' => rp_get_theme_mod('footer_twitter'),
            'icon' => 'fab fa-twitter',
            'label' => 'توییتر'
        ),
        'facebook' => array(
            'url' => rp_get_theme_mod('footer_facebook'),
            'icon' => 'fab fa-facebook',
            'label' => 'فیس بوک'
        )
    );
}

/**
 * Display social links
 */
function restropress_display_social_links($class = '') {
    $social_links = restropress_get_social_links();
    
    echo '<div class="rp-social-links ' . esc_attr($class) . '">';
    
    foreach ($social_links as $network => $data) {
        if (!empty($data['url'])) {
            printf(
                '<a href="%s" class="rp-social-link rp-social-%s" target="_blank" rel="noopener" aria-label="%s">',
                esc_url($data['url']),
                esc_attr($network),
                esc_attr($data['label'])
            );
            echo '<i class="' . esc_attr($data['icon']) . '"></i>';
            echo '</a>';
        }
    }
    
    echo '</div>';
}

/**
 * Check if WooCommerce is active
 */
function restropress_is_woocommerce_active() {
    return class_exists('WooCommerce');
}

/**
 * Get cart count
 */
function restropress_get_cart_count() {
    if (restropress_is_woocommerce_active()) {
        return WC()->cart->get_cart_contents_count();
    }
    return 0;
}

/**
 * Get cart total
 */
function restropress_get_cart_total() {
    if (restropress_is_woocommerce_active()) {
        return WC()->cart->get_cart_total();
    }
    return '';
}

/**
 * Add to cart fragment
 */
function restropress_add_to_cart_fragment($fragments) {
    $fragments['.rp-cart-count'] = '<span class="rp-cart-count">' . restropress_get_cart_count() . '</span>';
    $fragments['.rp-cart-total'] = '<span class="rp-cart-total">' . restropress_get_cart_total() . '</span>';
    return $fragments;
}
add_filter('woocommerce_add_to_cart_fragments', 'restropress_add_to_cart_fragment');

/**
 * Custom excerpt length
 */
function restropress_excerpt_length($length) {
    return 20;
}
add_filter('excerpt_length', 'restropress_excerpt_length');

/**
 * Custom excerpt more
 */
function restropress_excerpt_more($more) {
    return '...';
}
add_filter('excerpt_more', 'restropress_excerpt_more');

/**
 * Enable SVG upload
 */
function restropress_mime_types($mimes) {
    $mimes['svg'] = 'image/svg+xml';
    return $mimes;
}
add_filter('upload_mimes', 'restropress_mime_types');

/**
 * Add theme support for Elementor
 */
function restropress_elementor_support() {
    add_theme_support('elementor');
}
add_action('after_setup_theme', 'restropress_elementor_support');