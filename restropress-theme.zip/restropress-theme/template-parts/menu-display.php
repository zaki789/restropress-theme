<?php
/**
 * Menu display template part with AJAX filtering
 *
 * @package RestroPress
 * @version 1.0.0
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

// Check if WooCommerce is active
if (!class_exists('WooCommerce')) {
    echo '<div class="rp-woocommerce-missing">';
    echo '<p>' . __('ووکامرس برای نمایش منو نیاز است.', 'restropress') . '</p>';
    echo '</div>';
    return;
}
?>

<section id="rp-menu-section" class="rp-menu-section">
    <div class="rp-container">
        <div class="rp-section-header">
            <h2 class="rp-section-title"><?php echo esc_html(rp_get_theme_mod('menu_section_title', 'منوی ما')); ?></h2>
            
            <?php
            $menu_description = rp_get_theme_mod('menu_section_description');
            if (!empty($menu_description)) :
            ?>
                <p class="rp-section-description"><?php echo wp_kses_post($menu_description); ?></p>
            <?php endif; ?>
        </div>

        <!-- Search and Filter Bar -->
        <div class="rp-menu-controls">
            <!-- Search Box -->
            <div class="rp-menu-search">
                <div class="rp-search-box">
                    <input type="text" class="rp-search-input" 
                           placeholder="<?php echo esc_attr(rp_get_theme_mod('menu_search_placeholder', 'جستجو در منو...')); ?>"
                           aria-label="<?php _e('جستجو در منو', 'restropress'); ?>">
                    <button class="rp-search-button" type="button" aria-label="<?php _e('جستجو', 'restropress'); ?>">
                        <i class="fas fa-search"></i>
                    </button>
                    <button class="rp-search-clear rp-hidden" type="button" aria-label="<?php _e('پاک کردن جستجو', 'restropress'); ?>">
                        <i class="fas fa-times"></i>
                    </button>
                </div>
            </div>

            <!-- Categories Filter -->
            <div class="rp-menu-filters">
                <div class="rp-categories-filter">
                    <button class="rp-category-btn rp-filter-all active" data-category-id="0" data-category-slug="all">
                        <span class="rp-category-name"><?php _e('همه موارد', 'restropress'); ?></span>
                        <span class="rp-category-count"><?php echo wp_count_posts('product')->publish; ?></span>
                    </button>
                    
                    <?php
                    $categories = get_terms(array(
                        'taxonomy' => 'product_cat',
                        'hide_empty' => true,
                        'parent' => 0,
                        'orderby' => 'menu_order',
                        'order' => 'ASC'
                    ));
                    
                    if (!empty($categories) && !is_wp_error($categories)) :
                        foreach ($categories as $category) :
                            $category_image = get_term_meta($category->term_id, 'thumbnail_id', true);
                            $category_color = get_term_meta($category->term_id, 'rp_category_color', true);
                    ?>
                            <button class="rp-category-btn" 
                                    data-category-id="<?php echo $category->term_id; ?>" 
                                    data-category-slug="<?php echo $category->slug; ?>"
                                    style="<?php echo $category_color ? '--rp-category-color: ' . esc_attr($category_color) : ''; ?>">
                                
                                <?php if ($category_image) : ?>
                                    <span class="rp-category-image">
                                        <?php echo wp_get_attachment_image($category_image, 'thumbnail', false, array('alt' => $category->name)); ?>
                                    </span>
                                <?php else : ?>
                                    <span class="rp-category-icon">
                                        <i class="fas fa-utensils"></i>
                                    </span>
                                <?php endif; ?>
                                
                                <span class="rp-category-name"><?php echo $category->name; ?></span>
                                <span class="rp-category-count"><?php echo $category->count; ?></span>
                            </button>
                    <?php endforeach; endif; ?>
                </div>
            </div>

            <!-- Sort Options -->
            <div class="rp-sort-options">
                <select class="rp-sort-select" aria-label="<?php _e('مرتب سازی', 'restropress'); ?>">
                    <option value="menu_order"><?php _e('پیش فرض', 'restropress'); ?></option>
                    <option value="popularity"><?php _e('محبوب ترین', 'restropress'); ?></option>
                    <option value="rating"><?php _e('بالاترین امتیاز', 'restropress'); ?></option>
                    <option value="date"><?php _e('جدیدترین', 'restropress'); ?></option>
                    <option value="price"><?php _e('ارزان ترین', 'restropress'); ?></option>
                    <option value="price-desc"><?php _e('گران ترین', 'restropress'); ?></option>
                </select>
            </div>
        </div>

        <!-- Products Grid -->
        <div class="rp-menu-content">
            <div class="rp-products-grid" 
                 data-posts-per-page="<?php echo esc_attr(rp_get_theme_mod('menu_products_per_page', 12)); ?>"
                 data-load-more="<?php echo esc_attr(rp_get_theme_mod('menu_load_more', 'true')); ?>">
                 
                <!-- Products will be loaded via AJAX -->
                <div class="rp-products-loading">
                    <div class="rp-loading-spinner"></div>
                    <p><?php _e('در حال بارگذاری منو...', 'restropress'); ?></p>
                </div>
            </div>

            <!-- Load More Button -->
            <div class="rp-load-more-container rp-hidden">
                <button class="rp-load-more-button">
                    <span class="rp-button-text"><?php _e('بارگذاری بیشتر', 'restropress'); ?></span>
                    <span class="rp-loading-spinner rp-hidden"></span>
                </button>
            </div>
        </div>

        <!-- Quick View Modal -->
        <div class="rp-quick-view-modal rp-hidden" role="dialog" aria-labelledby="rp-quick-view-title">
            <div class="rp-quick-view-backdrop"></div>
            <div class="rp-quick-view-container">
                <div class="rp-quick-view-content">
                    <!-- Content will be loaded via AJAX -->
                </div>
                <button class="rp-quick-view-close" aria-label="<?php _e('بستن', 'restropress'); ?>">
                    <i class="fas fa-times"></i>
                </button>
            </div>
        </div>
    </div>
</section>

<style>
.rp-menu-section {
    padding: 4rem 0;
    background: var(--rp-light-bg);
    position: relative;
}

.rp-section-header {
    text-align: center;
    margin-bottom: 3rem;
}

.rp-section-title {
    font-family: var(--rp-primary-font);
    font-size: 2.5rem;
    color: var(--rp-secondary-color);
    margin-bottom: 1rem;
    font-weight: 600;
}

.rp-section-description {
    font-size: 1.1rem;
    color: #666;
    max-width: 600px;
    margin: 0 auto;
    line-height: 1.6;
}

.rp-menu-controls {
    display: flex;
    flex-direction: column;
    gap: 2rem;
    margin-bottom: 3rem;
}

.rp-menu-search {
    display: flex;
    justify-content: center;
}

.rp-search-box {
    position: relative;
    width: 100%;
    max-width: 400px;
}

.rp-search-input {
    width: 100%;
    padding: 1rem 3rem 1rem 1.5rem;
    border: 2px solid var(--rp-border-color);
    border-radius: var(--rp-border-radius-lg);
    font-family: var(--rp-secondary-font);
    font-size: 1rem;
    transition: all 0.3s ease;
    background: white;
}

.rp-search-input:focus {
    outline: none;
    border-color: var(--rp-primary-color);
    box-shadow: 0 0 0 3px rgba(200, 169, 126, 0.1);
}

.rp-search-button,
.rp-search-clear {
    position: absolute;
    top: 50%;
    transform: translateY(-50%);
    background: none;
    border: none;
    color: #666;
    cursor: pointer;
    padding: 0.5rem;
    transition: color 0.3s ease;
}

.rp-search-button {
    left: 0.5rem;
}

.rp-search-clear {
    right: 0.5rem;
}

.rp-search-button:hover,
.rp-search-clear:hover {
    color: var(--rp-primary-color);
}

.rp-menu-filters {
    overflow-x: auto;
    padding-bottom: 1rem;
}

.rp-categories-filter {
    display: flex;
    gap: 1rem;
    justify-content: center;
    flex-wrap: wrap;
    min-width: min-content;
}

.rp-category-btn {
    display: flex;
    align-items: center;
    gap: 0.75rem;
    padding: 1rem 1.5rem;
    background: white;
    border: 2px solid var(--rp-border-color);
    border-radius: var(--rp-border-radius-lg);
    cursor: pointer;
    transition: all 0.3s ease;
    font-family: var(--rp-secondary-font);
    font-weight: 500;
    color: var(--rp-text-color);
    white-space: nowrap;
    min-width: 120px;
    justify-content: center;
}

.rp-category-btn:hover {
    border-color: var(--rp-primary-color);
    transform: translateY(-2px);
    box-shadow: var(--rp-shadow-md);
}

.rp-category-btn.active {
    background: var(--rp-primary-color);
    border-color: var(--rp-primary-color);
    color: white;
}

.rp-category-image,
.rp-category-icon {
    width: 24px;
    height: 24px;
    display: flex;
    align-items: center;
    justify-content: center;
}

.rp-category-image img {
    width: 100%;
    height: 100%;
    object-fit: cover;
    border-radius: 50%;
}

.rp-category-icon {
    color: var(--rp-category-color, var(--rp-primary-color));
    font-size: 1rem;
}

.rp-category-name {
    font-size: 0.9rem;
}

.rp-category-count {
    background: rgba(0,0,0,0.1);
    padding: 0.25rem 0.5rem;
    border-radius: 20px;
    font-size: 0.8rem;
    min-width: 24px;
    text-align: center;
}

.rp-category-btn.active .rp-category-count {
    background: rgba(255,255,255,0.2);
}

.rp-sort-options {
    display: flex;
    justify-content: center;
}

.rp-sort-select {
    padding: 0.75rem 1rem;
    border: 2px solid var(--rp-border-color);
    border-radius: var(--rp-border-radius-md);
    font-family: var(--rp-secondary-font);
    font-size: 0.9rem;
    background: white;
    cursor: pointer;
    min-width: 150px;
}

.rp-sort-select:focus {
    outline: none;
    border-color: var(--rp-primary-color);
}

.rp-products-grid {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
    gap: 2rem;
    margin-bottom: 2rem;
}

.rp-products-loading {
    grid-column: 1 / -1;
    text-align: center;
    padding: 3rem;
    color: #666;
}

.rp-load-more-container {
    text-align: center;
    margin-top: 2rem;
}

.rp-load-more-button {
    padding: 1rem 2rem;
    background: var(--rp-primary-color);
    color: white;
    border: none;
    border-radius: var(--rp-border-radius-lg);
    font-family: var(--rp-secondary-font);
    font-weight: 600;
    cursor: pointer;
    transition: all 0.3s ease;
    display: inline-flex;
    align-items: center;
    gap: 0.5rem;
}

.rp-load-more-button:hover {
    background: var(--rp-accent-color);
    transform: translateY(-2px);
    box-shadow: var(--rp-shadow-md);
}

.rp-load-more-button:disabled {
    opacity: 0.6;
    cursor: not-allowed;
    transform: none;
}

/* Quick View Modal */
.rp-quick-view-modal {
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    z-index: 10000;
    display: flex;
    align-items: center;
    justify-content: center;
    padding: 2rem;
}

.rp-quick-view-backdrop {
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: rgba(0,0,0,0.8);
    backdrop-filter: blur(5px);
}

.rp-quick-view-container {
    position: relative;
    background: white;
    border-radius: var(--rp-border-radius-lg);
    max-width: 900px;
    width: 100%;
    max-height: 90vh;
    overflow: auto;
    box-shadow: var(--rp-shadow-xl);
}

.rp-quick-view-close {
    position: absolute;
    top: 1rem;
    left: 1rem;
    background: rgba(0,0,0,0.7);
    color: white;
    border: none;
    border-radius: 50%;
    width: 40px;
    height: 40px;
    display: flex;
    align-items: center;
    justify-content: center;
    cursor: pointer;
    z-index: 1;
    transition: all 0.3s ease;
}

.rp-quick-view-close:hover {
    background: var(--rp-error-color);
    transform: rotate(90deg);
}

@media (max-width: 768px) {
    .rp-menu-controls {
        gap: 1.5rem;
    }
    
    .rp-categories-filter {
        justify-content: flex-start;
        flex-wrap: nowrap;
    }
    
    .rp-category-btn {
        min-width: 140px;
        flex-direction: column;
        gap: 0.5rem;
        text-align: center;
    }
    
    .rp-products-grid {
        grid-template-columns: 1fr;
        gap: 1.5rem;
    }
    
    .rp-quick-view-modal {
        padding: 1rem;
    }
    
    .rp-section-title {
        font-size: 2rem;
    }
}

@media (max-width: 480px) {
    .rp-menu-controls {
        gap: 1rem;
    }
    
    .rp-category-btn {
        min-width: 120px;
        padding: 0.75rem 1rem;
    }
    
    .rp-category-name {
        font-size: 0.8rem;
    }
}
</style>