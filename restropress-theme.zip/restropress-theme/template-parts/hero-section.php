<?php
/**
 * Hero section template part
 *
 * @package RestroPress
 * @version 1.0.0
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

$hero_title = rp_get_theme_mod('hero_title', get_bloginfo('name'));
$hero_subtitle = rp_get_theme_mod('hero_subtitle', get_bloginfo('description'));
$hero_button_text = rp_get_theme_mod('hero_button_text', 'مشاهده منو');
$hero_button_action = rp_get_theme_mod('hero_button_action', 'scroll');
$hero_overlay = rp_get_theme_mod('hero_overlay_opacity', '0.5');
?>

<section class="rp-hero-section" style="--rp-hero-bg-image: <?php echo rp_get_hero_background(); ?>; --rp-hero-overlay: <?php echo esc_attr($hero_overlay); ?>;">
    <div class="rp-hero-overlay"></div>
    
    <div class="rp-container">
        <div class="rp-hero-content">
            <?php if (!empty($hero_title)) : ?>
                <h1 class="rp-hero-title">
                    <?php echo wp_kses_post($hero_title); ?>
                </h1>
            <?php endif; ?>
            
            <?php if (!empty($hero_subtitle)) : ?>
                <p class="rp-hero-subtitle">
                    <?php echo wp_kses_post($hero_subtitle); ?>
                </p>
            <?php endif; ?>
            
            <div class="rp-hero-buttons">
                <?php if ($hero_button_action === 'scroll') : ?>
                    <a href="#rp-menu-section" class="rp-menu-button rp-primary-button" data-action="scroll">
                        <span class="rp-button-text"><?php echo esc_html($hero_button_text); ?></span>
                        <i class="fas fa-chevron-down rp-button-icon"></i>
                    </a>
                <?php else : ?>
                    <?php
                    $menu_page_id = rp_get_theme_mod('hero_menu_page');
                    $menu_page_url = $menu_page_id ? get_permalink($menu_page_id) : (function_exists('wc_get_page_permalink') ? wc_get_page_permalink('shop') : '#');
                    ?>
                    <a href="<?php echo esc_url($menu_page_url); ?>" class="rp-menu-button rp-primary-button" data-action="page">
                        <span class="rp-button-text"><?php echo esc_html($hero_button_text); ?></span>
                        <i class="fas fa-arrow-left rp-button-icon"></i>
                    </a>
                <?php endif; ?>
                
                <?php
                $secondary_button_text = rp_get_theme_mod('hero_secondary_button_text', 'رزرو میز');
                $secondary_button_url = rp_get_theme_mod('hero_secondary_button_url', '#reservation');
                
                if (!empty($secondary_button_text)) :
                ?>
                    <a href="<?php echo esc_url($secondary_button_url); ?>" class="rp-secondary-button">
                        <span class="rp-button-text"><?php echo esc_html($secondary_button_text); ?></span>
                        <i class="fas fa-calendar-alt rp-button-icon"></i>
                    </a>
                <?php endif; ?>
            </div>
            
            <?php
            // Hero features list
            $hero_features = rp_get_theme_mod('hero_features', '');
            if (!empty($hero_features)) :
                $features = explode("\n", $hero_features);
            ?>
                <div class="rp-hero-features">
                    <?php foreach ($features as $feature) : 
                        $feature = trim($feature);
                        if (!empty($feature)) :
                    ?>
                        <div class="rp-hero-feature">
                            <i class="fas fa-check rp-feature-icon"></i>
                            <span class="rp-feature-text"><?php echo esc_html($feature); ?></span>
                        </div>
                    <?php endif; endforeach; ?>
                </div>
            <?php endif; ?>
        </div>
    </div>
    
    <!-- Scroll indicator -->
    <div class="rp-scroll-indicator">
        <div class="rp-scroll-arrow"></div>
    </div>
</section>

<style>
.rp-hero-section {
    position: relative;
    height: 100vh;
    min-height: 600px;
    background: linear-gradient(rgba(0,0,0,var(--rp-hero-overlay)), rgba(0,0,0,var(--rp-hero-overlay))), var(--rp-hero-bg-image);
    background-size: cover;
    background-position: center;
    background-attachment: fixed;
    display: flex;
    align-items: center;
    justify-content: center;
    color: white;
    margin-top: 80px;
}

.rp-hero-overlay {
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: rgba(0,0,0,0.3);
    z-index: 1;
}

.rp-hero-content {
    position: relative;
    z-index: 2;
    text-align: center;
    max-width: 800px;
    padding: 0 20px;
}

.rp-hero-title {
    font-family: var(--rp-primary-font);
    font-size: clamp(2.5rem, 5vw, 4rem);
    margin-bottom: 1.5rem;
    font-weight: 700;
    line-height: 1.2;
    opacity: 0;
    transform: translateY(30px);
    animation: rpFadeInUp 1s ease 0.5s forwards;
}

.rp-hero-subtitle {
    font-family: var(--rp-secondary-font);
    font-size: clamp(1rem, 2vw, 1.25rem);
    margin-bottom: 2.5rem;
    opacity: 0;
    transform: translateY(30px);
    animation: rpFadeInUp 1s ease 0.8s forwards;
    line-height: 1.6;
    color: rgba(255,255,255,0.9);
}

.rp-hero-buttons {
    display: flex;
    gap: 1rem;
    justify-content: center;
    flex-wrap: wrap;
    margin-bottom: 3rem;
    opacity: 0;
    transform: translateY(30px);
    animation: rpFadeInUp 1s ease 1.1s forwards;
}

.rp-primary-button,
.rp-secondary-button {
    display: inline-flex;
    align-items: center;
    gap: 0.75rem;
    padding: 1rem 2rem;
    border-radius: var(--rp-border-radius-lg);
    font-family: var(--rp-secondary-font);
    font-weight: 600;
    text-decoration: none;
    transition: all 0.3s ease;
    font-size: 1rem;
    border: 2px solid transparent;
}

.rp-primary-button {
    background: var(--rp-primary-color);
    color: var(--rp-secondary-color);
}

.rp-primary-button:hover {
    background: var(--rp-accent-color);
    transform: translateY(-2px);
    box-shadow: var(--rp-shadow-xl);
    color: var(--rp-secondary-color);
}

.rp-secondary-button {
    background: transparent;
    color: white;
    border-color: rgba(255,255,255,0.3);
}

.rp-secondary-button:hover {
    background: rgba(255,255,255,0.1);
    border-color: rgba(255,255,255,0.5);
    transform: translateY(-2px);
}

.rp-hero-features {
    display: flex;
    flex-wrap: wrap;
    justify-content: center;
    gap: 1.5rem;
    opacity: 0;
    animation: rpFadeIn 1s ease 1.4s forwards;
}

.rp-hero-feature {
    display: flex;
    align-items: center;
    gap: 0.5rem;
    font-size: 0.9rem;
    color: rgba(255,255,255,0.8);
}

.rp-feature-icon {
    color: var(--rp-primary-color);
    font-size: 0.8rem;
}

.rp-scroll-indicator {
    position: absolute;
    bottom: 2rem;
    left: 50%;
    transform: translateX(-50%);
    z-index: 2;
    opacity: 0;
    animation: rpFadeIn 1s ease 2s forwards;
}

.rp-scroll-arrow {
    width: 30px;
    height: 30px;
    border-right: 2px solid rgba(255,255,255,0.7);
    border-bottom: 2px solid rgba(255,255,255,0.7);
    transform: rotate(45deg);
    animation: rpBounce 2s infinite;
}

@keyframes rpFadeInUp {
    to {
        opacity: 1;
        transform: translateY(0);
    }
}

@keyframes rpFadeIn {
    to {
        opacity: 1;
    }
}

@keyframes rpBounce {
    0%, 20%, 50%, 80%, 100% {
        transform: rotate(45deg) translateY(0);
    }
    40% {
        transform: rotate(45deg) translateY(-10px);
    }
    60% {
        transform: rotate(45deg) translateY(-5px);
    }
}

@media (max-width: 768px) {
    .rp-hero-section {
        height: 80vh;
        min-height: 500px;
        background-attachment: scroll;
        margin-top: 70px;
    }
    
    .rp-hero-buttons {
        flex-direction: column;
        align-items: center;
    }
    
    .rp-primary-button,
    .rp-secondary-button {
        width: 200px;
        justify-content: center;
    }
    
    .rp-hero-features {
        gap: 1rem;
    }
}
</style>