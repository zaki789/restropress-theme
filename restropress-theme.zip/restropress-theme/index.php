<?php
/**
 * The main template file
 *
 * @package RestroPress
 * @version 1.0.0
 */

get_header();
?>

<div class="rp-container">
    <div class="rp-content-area">
        <?php if (have_posts()) : ?>
            <div class="rp-posts-grid">
                <?php while (have_posts()) : the_post(); ?>
                    <article id="post-<?php the_ID(); ?>" <?php post_class('rp-post-card'); ?>>
                        <?php if (has_post_thumbnail()) : ?>
                            <div class="rp-post-thumbnail">
                                <a href="<?php the_permalink(); ?>">
                                    <?php the_post_thumbnail('rp-product-thumb'); ?>
                                </a>
                            </div>
                        <?php endif; ?>
                        
                        <div class="rp-post-content">
                            <header class="rp-post-header">
                                <h2 class="rp-post-title">
                                    <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
                                </h2>
                                <div class="rp-post-meta">
                                    <time datetime="<?php echo get_the_date('c'); ?>">
                                        <?php echo get_the_date(); ?>
                                    </time>
                                </div>
                            </header>
                            
                            <div class="rp-post-excerpt">
                                <?php the_excerpt(); ?>
                            </div>
                            
                            <footer class="rp-post-footer">
                                <a href="<?php the_permalink(); ?>" class="rp-read-more">
                                    <?php _e('ادامه مطلب', 'restropress'); ?>
                                </a>
                            </footer>
                        </div>
                    </article>
                <?php endwhile; ?>
            </div>
            
            <!-- Pagination -->
            <div class="rp-pagination">
                <?php
                the_posts_pagination(array(
                    'mid_size' => 2,
                    'prev_text' => __('&larr; قبلی', 'restropress'),
                    'next_text' => __('بعدی &rarr;', 'restropress'),
                ));
                ?>
            </div>
            
        <?php else : ?>
            <div class="rp-no-content">
                <h2><?php _e('مطلبی یافت نشد', 'restropress'); ?></h2>
                <p><?php _e('متاسفانه هیچ مطلبی مطابق با جستجوی شما یافت نشد.', 'restropress'); ?></p>
            </div>
        <?php endif; ?>
    </div>
    
    <?php if (is_active_sidebar('main-sidebar')) : ?>
        <aside class="rp-sidebar">
            <?php dynamic_sidebar('main-sidebar'); ?>
        </aside>
    <?php endif; ?>
</div>

<?php
get_footer();