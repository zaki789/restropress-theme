<?php
/**
 * The header for our theme
 *
 * @package RestroPress
 * @version 1.0.0
 */
?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="profile" href="https://gmpg.org/xfn/11">
    <?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>
<?php wp_body_open(); ?>

<div id="page" class="rp-site">
    <header class="rp-header">
        <div class="rp-container">
            <div class="rp-header-inner">
                <!-- Logo -->
                <div class="rp-logo">
                    <?php
                    $logo = get_theme_mod('rp_logo');
                    $site_name = get_bloginfo('name');
                    
                    if ($logo) {
                        echo '<img src="' . esc_url($logo) . '" alt="' . esc_attr($site_name) . '" class="rp-logo-image">';
                    } else {
                        echo '<h1 class="rp-logo-text">' . esc_html($site_name) . '</h1>';
                    }
                    ?>
                </div>

                <!-- Navigation -->
                <nav class="rp-nav">
                    <?php
                    wp_nav_menu(array(
                        'theme_location' => 'primary',
                        'container' => false,
                        'menu_class' => 'rp-nav-menu',
                        'fallback_cb' => false,
                        'depth' => 2
                    ));
                    ?>
                </nav>

                <!-- Header Actions -->
                <div class="rp-header-actions">
                    <!-- Cart Icon -->
                    <?php if (class_exists('WooCommerce')) : ?>
                        <div class="rp-cart-icon">
                            <i class="fas fa-shopping-bag"></i>
                            <span class="rp-cart-count">
                                <?php echo WC()->cart->get_cart_contents_count(); ?>
                            </span>
                        </div>
                    <?php endif; ?>

                    <!-- Account Icon -->
                    <div class="rp-account-icon">
                        <i class="fas fa-user"></i>
                    </div>

                    <!-- Mobile Menu Toggle -->
                    <button class="rp-mobile-toggle rp-hidden-desktop">
                        <span></span>
                        <span></span>
                        <span></span>
                    </button>
                </div>
            </div>
        </div>
    </header>

    <!-- Mobile Menu -->
    <div class="rp-mobile-menu rp-hidden-desktop">
        <?php
        wp_nav_menu(array(
            'theme_location' => 'mobile',
            'container' => false,
            'menu_class' => 'rp-mobile-nav',
            'fallback_cb' => false
        ));
        ?>
    </div>

    <main id="main" class="rp-main">