<?php
/**
 * The footer for our theme
 *
 * @package RestroPress
 * @version 1.0.0
 */
?>
    </main><!-- .rp-main -->

    <footer class="rp-footer">
        <div class="rp-container">
            <div class="rp-footer-content">
                <!-- About Section -->
                <div class="rp-footer-section">
                    <h3><?php echo esc_html(get_bloginfo('name')); ?></h3>
                    <p><?php echo wp_kses_post(get_bloginfo('description')); ?></p>
                    
                    <div class="rp-social-links">
                        <?php
                        $social_links = array(
                            'instagram' => array(
                                'url' => rp_get_theme_mod('footer_instagram'),
                                'icon' => 'fab fa-instagram'
                            ),
                            'whatsapp' => array(
                                'url' => rp_get_theme_mod('footer_whatsapp'),
                                'icon' => 'fab fa-whatsapp'
                            ),
                            'telegram' => array(
                                'url' => rp_get_theme_mod('footer_telegram'),
                                'icon' => 'fab fa-telegram'
                            )
                        );
                        
                        foreach ($social_links as $network => $data) {
                            if (!empty($data['url'])) {
                                echo '<a href="' . esc_url($data['url']) . '" class="rp-social-link" target="_blank" rel="noopener">';
                                echo '<i class="' . esc_attr($data['icon']) . '"></i>';
                                echo '</a>';
                            }
                        }
                        ?>
                    </div>
                </div>

                <!-- Contact Section -->
                <div class="rp-footer-section">
                    <h3><?php _e('اطلاعات تماس', 'restropress'); ?></h3>
                    <div class="rp-contact-info">
                        <?php
                        $contact_info = rp_get_footer_contact();
                        
                        if (!empty($contact_info['address'])) {
                            echo '<div class="rp-contact-item">';
                            echo '<i class="fas fa-map-marker-alt"></i>';
                            echo '<span>' . wp_kses_post($contact_info['address']) . '</span>';
                            echo '</div>';
                        }
                        
                        if (!empty($contact_info['phone'])) {
                            echo '<div class="rp-contact-item">';
                            echo '<i class="fas fa-phone"></i>';
                            echo '<a href="tel:' . esc_attr($contact_info['phone']) . '">' . esc_html($contact_info['phone']) . '</a>';
                            echo '</div>';
                        }
                        
                        if (!empty($contact_info['email'])) {
                            echo '<div class="rp-contact-item">';
                            echo '<i class="fas fa-envelope"></i>';
                            echo '<a href="mailto:' . esc_attr($contact_info['email']) . '">' . esc_html($contact_info['email']) . '</a>';
                            echo '</div>';
                        }
                        ?>
                    </div>
                </div>

                <!-- Quick Links -->
                <div class="rp-footer-section">
                    <h3><?php _e('لینک های سریع', 'restropress'); ?></h3>
                    <?php
                    wp_nav_menu(array(
                        'theme_location' => 'footer',
                        'container' => false,
                        'menu_class' => 'rp-footer-nav',
                        'depth' => 1
                    ));
                    ?>
                </div>

                <!-- Business Hours -->
                <div class="rp-footer-section">
                    <h3><?php _e('ساعات کاری', 'restropress'); ?></h3>
                    <?php
                    $business_hours = rp_get_theme_mod('business_hours', '');
                    if ($business_hours) {
                        echo '<div class="rp-business-hours">';
                        echo wp_kses_post(wpautop($business_hours));
                        echo '</div>';
                    } else {
                        echo '<p>' . __('هر روز از ۸:۰۰ تا ۲۴:۰۰', 'restropress') . '</p>';
                    }
                    ?>
                </div>
            </div>

            <!-- Footer Bottom -->
            <div class="rp-footer-bottom">
                <p>&copy; <?php echo date('Y'); ?> <?php bloginfo('name'); ?>. <?php _e('تمام حقوق محفوظ است.', 'restropress'); ?></p>
                <?php
                $credit = rp_get_theme_mod('footer_credit', '');
                if ($credit) {
                    echo '<p>' . wp_kses_post($credit) . '</p>';
                }
                ?>
            </div>
        </div>
    </footer>
</div><!-- .rp-site -->

<?php wp_footer(); ?>
</body>
</html>