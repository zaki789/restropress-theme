<?php
/**
 * RestroPress Theme Functions
 * 
 * @package RestroPress
 * @version 1.0.0
 */

if (!defined('ABSPATH')) {
    exit;
}

// Constants
define('RESTROPRESS_VERSION', '1.0.0');
define('RESTROPRESS_TEMPLATE_URL', get_template_directory_uri());
define('RESTROPRESS_TEMPLATE_PATH', get_template_directory());

/**
 * Main Theme Class
 */
class RestroPress_Theme {
    
    public function __construct() {
        add_action('after_setup_theme', array($this, 'theme_setup'));
        add_action('wp_enqueue_scripts', array($this, 'enqueue_scripts'));
        add_action('customize_register', array($this, 'customize_register'));
        add_action('widgets_init', array($this, 'register_sidebars'));
        
        // AJAX handlers
        add_action('wp_ajax_rp_filter_products', array($this, 'ajax_filter_products'));
        add_action('wp_ajax_nopriv_rp_filter_products', array($this, 'ajax_filter_products'));
        add_action('wp_ajax_rp_add_to_cart', array($this, 'ajax_add_to_cart'));
        add_action('wp_ajax_nopriv_rp_add_to_cart', array($this, 'ajax_add_to_cart'));
        
        // WooCommerce support
        add_action('woocommerce_loaded', array($this, 'woocommerce_support'));
        
        // Include required files
        $this->include_files();
    }
    
    /**
     * Include required files
     */
    private function include_files() {
        $includes = array(
            '/inc/custom-functions.php',
            '/inc/customizer.php',
            '/inc/ajax-handler.php'
        );
        
        foreach ($includes as $file) {
            $filepath = RESTROPRESS_TEMPLATE_PATH . $file;
            if (file_exists($filepath)) {
                require_once $filepath;
            }
        }
    }
    
    /**
     * Theme setup
     */
    public function theme_setup() {
        load_theme_textdomain('restropress', get_template_directory() . '/languages');
        
        add_theme_support('title-tag');
        add_theme_support('post-thumbnails');
        add_theme_support('custom-logo');
        add_theme_support('html5', array(
            'search-form',
            'comment-form',
            'comment-list',
            'gallery',
            'caption',
        ));
        
        add_theme_support('customize-selective-refresh-widgets');
        add_theme_support('responsive-embeds');
        
        // WooCommerce support
        add_theme_support('woocommerce');
        add_theme_support('wc-product-gallery-zoom');
        add_theme_support('wc-product-gallery-lightbox');
        add_theme_support('wc-product-gallery-slider');
        
        register_nav_menus(array(
            'primary' => __('منوی اصلی', 'restropress'),
            'footer' => __('منوی فوتر', 'restropress'),
        ));
        
        // Custom image sizes
        add_image_size('rp-product-thumb', 400, 300, true);
        add_image_size('rp-hero-bg', 1920, 1080, true);
    }
    
    /**
     * Enqueue scripts and styles
     */
    public function enqueue_scripts() {
        // Styles
        wp_enqueue_style('restropress-style', get_stylesheet_uri(), array(), RESTROPRESS_VERSION);
        wp_enqueue_style('rp-main-style', RESTROPRESS_TEMPLATE_URL . '/assets/css/main.css', array(), RESTROPRESS_VERSION);
        
        // Google Fonts
        wp_enqueue_style('rp-google-fonts', 'https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;500;600;700&family=Open+Sans:wght@300;400;500;600;700&family=Roboto:wght@300;400;500;700&display=swap', array(), null);
        
        // Font Awesome
        wp_enqueue_style('rp-font-awesome', 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css', array(), '6.0.0');
        
        // Scripts
        wp_enqueue_script('jquery');
        wp_enqueue_script('rp-main-js', RESTROPRESS_TEMPLATE_URL . '/assets/js/main.js', array('jquery'), RESTROPRESS_VERSION, true);
        wp_enqueue_script('rp-ajax-menu', RESTROPRESS_TEMPLATE_URL . '/assets/js/ajax-menu.js', array('jquery'), RESTROPRESS_VERSION, true);
        
        // Localize script for AJAX
        wp_localize_script('rp-ajax-menu', 'rp_ajax', array(
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('rp_ajax_nonce'),
            'loading_text' => __('در حال بارگذاری...', 'restropress'),
            'error_text' => __('خطا در بارگذاری', 'restropress')
        ));
    }
    
    /**
     * Customizer settings
     */
    public function customize_register($wp_customize) {
        // Customizer code will be in inc/customizer.php
    }
    
    /**
     * Register sidebars
     */
    public function register_sidebars() {
        register_sidebar(array(
            'name' => __('سایدبار اصلی', 'restropress'),
            'id' => 'main-sidebar',
            'description' => __('ویجت‌های نمایش داده شده در سایدبار اصلی', 'restropress'),
            'before_widget' => '<div id="%1$s" class="widget %2$s">',
            'after_widget' => '</div>',
            'before_title' => '<h3 class="widget-title">',
            'after_title' => '</h3>',
        ));
    }
    
    /**
     * AJAX filter products - Basic version
     */
    public function ajax_filter_products() {
        // Check nonce for security
        if (!wp_verify_nonce($_POST['nonce'], 'rp_ajax_nonce')) {
            wp_send_json_error('Nonce verification failed');
        }
        
        $category_id = isset($_POST['category_id']) ? intval($_POST['category_id']) : 0;
        
        $args = array(
            'post_type' => 'product',
            'posts_per_page' => 12,
            'post_status' => 'publish'
        );
        
        if ($category_id > 0) {
            $args['tax_query'] = array(
                array(
                    'taxonomy' => 'product_cat',
                    'field' => 'term_id',
                    'terms' => $category_id
                )
            );
        }
        
        $products = new WP_Query($args);
        
        ob_start();
        
        if ($products->have_posts()) {
            while ($products->have_posts()) {
                $products->the_post();
                global $product;
                ?>
                <div class="rp-product-card">
                    <?php if (has_post_thumbnail()) : ?>
                        <img src="<?php echo get_the_post_thumbnail_url(get_the_ID(), 'rp-product-thumb'); ?>" alt="<?php the_title(); ?>" class="rp-product-image">
                    <?php endif; ?>
                    
                    <div class="rp-product-info">
                        <h3 class="rp-product-title"><?php the_title(); ?></h3>
                        
                        <div class="rp-product-price">
                            <?php echo $product->get_price_html(); ?>
                        </div>
                        
                        <button class="rp-add-to-cart" data-product-id="<?php echo get_the_ID(); ?>">
                            <?php _e('افزودن به سبد خرید', 'restropress'); ?>
                        </button>
                    </div>
                </div>
                <?php
            }
            wp_reset_postdata();
        } else {
            echo '<p class="rp-no-products">' . __('محصولی یافت نشد.', 'restropress') . '</p>';
        }
        
        $output = ob_get_clean();
        wp_send_json_success($output);
        wp_die();
    }
    
    /**
     * AJAX add to cart - Basic version
     */
    public function ajax_add_to_cart() {
        // Check nonce for security
        if (!wp_verify_nonce($_POST['nonce'], 'rp_ajax_nonce')) {
            wp_send_json_error('Nonce verification failed');
        }
        
        $product_id = isset($_POST['product_id']) ? intval($_POST['product_id']) : 0;
        
        if ($product_id === 0 || !class_exists('WooCommerce')) {
            wp_send_json_error(__('خطا در افزودن به سبد خرید.', 'restropress'));
        }
        
        // Add to cart
        $cart_item_key = WC()->cart->add_to_cart($product_id, 1);
        
        if ($cart_item_key) {
            $response = array(
                'success' => true,
                'message' => __('محصول به سبد خرید اضافه شد.', 'restropress'),
                'cart_count' => WC()->cart->get_cart_contents_count()
            );
            wp_send_json_success($response);
        } else {
            wp_send_json_error(__('خطا در افزودن به سبد خرید.', 'restropress'));
        }
        
        wp_die();
    }
    
    /**
     * WooCommerce support
     */
    public function woocommerce_support() {
        // Remove WooCommerce default styles
        add_filter('woocommerce_enqueue_styles', '__return_empty_array');
    }
}

// Initialize the theme
new RestroPress_Theme();

/**
 * Helper functions
 */
function rp_get_theme_mod($key, $default = '') {
    return get_theme_mod('rp_' . $key, $default);
}

function rp_get_hero_background() {
    $bg_type = rp_get_theme_mod('hero_bg_type', 'image');
    
    if ($bg_type === 'color') {
        return rp_get_theme_mod('hero_bg_color', '#1a1a1a');
    } else {
        $bg_image = rp_get_theme_mod('hero_bg_image', '');
        return $bg_image ? 'url(' . esc_url($bg_image) . ')' : 'url(' . RESTROPRESS_TEMPLATE_URL . '/assets/images/default-hero.jpg)';
    }
}
?>