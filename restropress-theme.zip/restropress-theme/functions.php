<?php
/**
 * RestroPress Theme Functions
 * 
 * @package RestroPress
 */

if (!defined('ABSPATH')) {
    exit;
}

// Constants
define('RESTROPRESS_VERSION', '1.0.0');
define('RESTROPRESS_TEMPLATE_URL', get_template_directory_uri());
define('RESTROPRESS_TEMPLATE_PATH', get_template_directory());

class RestroPress_Theme {
    
    public function __construct() {
        add_action('after_setup_theme', array($this, 'theme_setup'));
        add_action('wp_enqueue_scripts', array($this, 'enqueue_scripts'));
        add_action('customize_register', array($this, 'customize_register'));
        add_action('widgets_init', array($this, 'register_sidebars'));
        
        // AJAX handlers
        add_action('wp_ajax_rp_filter_products', array($this, 'ajax_filter_products'));
        add_action('wp_ajax_nopriv_rp_filter_products', array($this, 'ajax_filter_products'));
        add_action('wp_ajax_rp_add_to_cart', array($this, 'ajax_add_to_cart'));
        add_action('wp_ajax_nopriv_rp_add_to_cart', array($this, 'ajax_add_to_cart'));
        
        // WooCommerce support
        add_action('after_setup_theme', array($this, 'woocommerce_support'));
        add_filter('woocommerce_enqueue_styles', array($this, 'woocommerce_styles'));
        
        $this->includes();
    }
    
    public function theme_setup() {
        load_theme_textdomain('restropress', get_template_directory() . '/languages');
        
        add_theme_support('title-tag');
        add_theme_support('post-thumbnails');
        add_theme_support('custom-logo');
        add_theme_support('html5', array(
            'search-form',
            'comment-form',
            'comment-list',
            'gallery',
            'caption',
        ));
        
        // Custom image sizes
        add_image_size('rp-product-thumb', 400, 300, true);
        add_image_size('rp-hero-bg', 1920, 1080, true);
        add_image_size('rp-product-large', 600, 400, true);
        
        register_nav_menus(array(
            'primary' => __('منوی اصلی', 'restropress'),
            'footer' => __('منوی فوتر', 'restropress'),
        ));
    }
    
    public function enqueue_scripts() {
        // Styles
        wp_enqueue_style('restropress-style', get_stylesheet_uri(), array(), RESTROPRESS_VERSION);
        wp_enqueue_style('rp-main-style', RESTROPRESS_TEMPLATE_URL . '/assets/css/main.css', array(), RESTROPRESS_VERSION);
        wp_enqueue_style('rp-responsive-style', RESTROPRESS_TEMPLATE_URL . '/assets/css/responsive.css', array(), RESTROPRESS_VERSION);
        
        // Google Fonts
        wp_enqueue_style('rp-google-fonts', 'https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;500;600;700&family=Open+Sans:wght@300;400;500;600;700&family=Roboto:wght@300;400;500;700&display=swap', array(), null);
        
        // Font Awesome for icons
        wp_enqueue_style('rp-font-awesome', 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css', array(), '6.0.0');
        
        // Scripts
        wp_enqueue_script('rp-main-js', RESTROPRESS_TEMPLATE_URL . '/assets/js/main.js', array('jquery'), RESTROPRESS_VERSION, true);
        wp_enqueue_script('rp-ajax-menu', RESTROPRESS_TEMPLATE_URL . '/assets/js/ajax-menu.js', array('jquery'), RESTROPRESS_VERSION, true);
        
        // Localize script for AJAX
        wp_localize_script('rp-ajax-menu', 'rp_ajax', array(
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('rp_nonce'),
            'loading_text' => __('در حال بارگذاری...', 'restropress'),
            'error_text' => __('خطا در بارگذاری', 'restropress'),
            'added_to_cart' => __('محصول به سبد خرید اضافه شد', 'restropress'),
            'add_to_cart_error' => __('خطا در افزودن به سبد خرید', 'restropress')
        ));
        
        // Add inline CSS for customizer settings
        $this->add_customizer_css();
    }
    
    public function customize_register($wp_customize) {
        require_once RESTROPRESS_TEMPLATE_PATH . '/inc/customizer.php';
    }
    
    public function register_sidebars() {
        register_sidebar(array(
            'name' => __('نوار کناری اصلی', 'restropress'),
            'id' => 'main-sidebar',
            'description' => __('ویجت‌های نمایش داده شده در نوار کناری', 'restropress'),
            'before_widget' => '<div id="%1$s" class="widget %2$s">',
            'after_widget' => '</div>',
            'before_title' => '<h3 class="widget-title">',
            'after_title' => '</h3>',
        ));
        
        register_sidebar(array(
            'name' => __('فوتر بخش ۱', 'restropress'),
            'id' => 'footer-1',
            'description' => __('ویجت‌های بخش اول فوتر', 'restropress'),
            'before_widget' => '<div id="%1$s" class="widget %2$s">',
            'after_widget' => '</div>',
            'before_title' => '<h3 class="widget-title">',
            'after_title' => '</h3>',
        ));
        
        register_sidebar(array(
            'name' => __('فوتر بخش ۲', 'restropress'),
            'id' => 'footer-2',
            'description' => __('ویجت‌های بخش دوم فوتر', 'restropress'),
            'before_widget' => '<div id="%1$s" class="widget %2$s">',
            'after_widget' => '</div>',
            'before_title' => '<h3 class="widget-title">',
            'after_title' => '</h3>',
        ));
    }
    
    public function woocommerce_support() {
        add_theme_support('woocommerce');
        add_theme_support('wc-product-gallery-zoom');
        add_theme_support('wc-product-gallery-lightbox');
        add_theme_support('wc-product-gallery-slider');
    }
    
    public function woocommerce_styles($enqueue_styles) {
        // Remove some WooCommerce styles
        unset($enqueue_styles['woocommerce-general']);
        unset($enqueue_styles['woocommerce-layout']);
        unset($enqueue_styles['woocommerce-smallscreen']);
        
        return $enqueue_styles;
    }
    
    public function ajax_filter_products() {
        check_ajax_referer('rp_nonce', 'nonce');
        
        $category_id = isset($_POST['category_id']) ? intval($_POST['category_id']) : 0;
        $per_page = isset($_POST['per_page']) ? intval($_POST['per_page']) : 12;
        
        $args = array(
            'post_type' => 'product',
            'posts_per_page' => $per_page,
            'post_status' => 'publish',
            'meta_query' => array(
                array(
                    'key' => '_visibility',
                    'value' => array('visible', 'catalog'),
                    'compare' => 'IN'
                )
            )
        );
        
        if ($category_id > 0) {
            $args['tax_query'] = array(
                array(
                    'taxonomy' => 'product_cat',
                    'field' => 'term_id',
                    'terms' => $category_id
                )
            );
        }
        
        $products = new WP_Query($args);
        
        ob_start();
        
        if ($products->have_posts()) {
            while ($products->have_posts()) {
                $products->the_post();
                global $product;
                
                $product_data = array(
                    'id' => get_the_ID(),
                    'title' => get_the_title(),
                    'excerpt' => get_the_excerpt(),
                    'thumbnail' => get_the_post_thumbnail_url(get_the_ID(), 'rp-product-thumb'),
                    'price' => $product->get_price_html(),
                    'regular_price' => $product->get_regular_price(),
                    'sale_price' => $product->get_sale_price(),
                    'on_sale' => $product->is_on_sale(),
                    'add_to_cart_url' => $product->add_to_cart_url(),
                    'product_url' => get_permalink(),
                );
                
                include RESTROPRESS_TEMPLATE_PATH . '/template-parts/product-card.php';
            }
            wp_reset_postdata();
        } else {
            echo '<div class="rp-no-products">';
            echo '<p>' . __('محصولی در این دسته بندی یافت نشد.', 'restropress') . '</p>';
            echo '</div>';
        }
        
        $output = ob_get_clean();
        
        wp_send_json_success($output);
        
        wp_die();
    }
    
    public function ajax_add_to_cart() {
        check_ajax_referer('rp_nonce', 'nonce');
        
        $product_id = isset($_POST['product_id']) ? intval($_POST['product_id']) : 0;
        $quantity = isset($_POST['quantity']) ? intval($_POST['quantity']) : 1;
        $variation_id = isset($_POST['variation_id']) ? intval($_POST['variation_id']) : 0;
        $variation = isset($_POST['variation']) ? $_POST['variation'] : array();
        
        if ($product_id === 0) {
            wp_send_json_error(__('محصول معتبر نیست.', 'restropress'));
        }
        
        // Add to cart
        if ($variation_id > 0) {
            $cart_item_key = WC()->cart->add_to_cart($product_id, $quantity, $variation_id, $variation);
        } else {
            $cart_item_key = WC()->cart->add_to_cart($product_id, $quantity);
        }
        
        if ($cart_item_key) {
            $response = array(
                'success' => true,
                'message' => __('محصول به سبد خرید اضافه شد.', 'restropress'),
                'cart_count' => WC()->cart->get_cart_contents_count(),
                'cart_total' => WC()->cart->get_cart_total(),
                'cart_subtotal' => WC()->cart->get_cart_subtotal()
            );
            wp_send_json_success($response);
        } else {
            wp_send_json_error(__('خطا در افزودن به سبد خرید.', 'restropress'));
        }
        
        wp_die();
    }
    
    private function add_customizer_css() {
        $css = "
            :root {
                --rp-primary-color: " . get_theme_mod('rp_primary_color', '#c8a97e') . ";
                --rp-secondary-color: " . get_theme_mod('rp_secondary_color', '#1a1a1a') . ";
                --rp-accent-color: " . get_theme_mod('rp_accent_color', '#d4af37') . ";
                --rp-primary-font: " . get_theme_mod('rp_primary_font', 'Playfair Display') . ";
                --rp-secondary-font: " . get_theme_mod('rp_secondary_font', 'Open Sans') . ";
                --rp-body-font: " . get_theme_mod('rp_body_font', 'Roboto') . ";
            }
        ";
        
        wp_add_inline_style('rp-main-style', $css);
    }
    
    private function includes() {
        require_once RESTROPRESS_TEMPLATE_PATH . '/inc/custom-functions.php';
        require_once RESTROPRESS_TEMPLATE_PATH . '/inc/customizer.php';
        require_once RESTROPRESS_TEMPLATE_PATH . '/inc/ajax-handler.php';
        
        // Template functions
        require_once RESTROPRESS_TEMPLATE_PATH . '/inc/template-functions.php';
    }
}

new RestroPress_Theme();

// Helper functions
function rp_get_theme_mod($key, $default = '') {
    return get_theme_mod('rp_' . $key, $default);
}

function rp_get_hero_background() {
    $bg_type = rp_get_theme_mod('hero_bg_type', 'image');
    
    if ($bg_type === 'color') {
        return rp_get_theme_mod('hero_bg_color', '#1a1a1a');
    } else {
        $bg_image = rp_get_theme_mod('hero_bg_image', '');
        return $bg_image ? 'url(' . esc_url($bg_image) . ')' : 'url(' . get_template_directory_uri() . '/assets/images/default-hero.jpg)';
    }
}

function rp_get_categories() {
    $categories = get_terms(array(
        'taxonomy' => 'product_cat',
        'hide_empty' => true,
        'parent' => 0
    ));
    
    return $categories;
}

function rp_get_logo() {
    if (has_custom_logo()) {
        return wp_get_attachment_image_src(get_theme_mod('custom_logo'), 'full');
    }
    
    return false;
}
?><?php
/**
 * RestroPress Theme Functions
 * 
 * @package RestroPress
 * @version 1.0.0
 */

if (!defined('ABSPATH')) {
    exit;
}

// Constants
define('RESTROPRESS_VERSION', '1.0.0');
define('RESTROPRESS_TEMPLATE_URL', get_template_directory_uri());
define('RESTROPRESS_TEMPLATE_PATH', get_template_directory());

/**
 * Main Theme Class
 */
class RestroPress_Theme {
    
    public function __construct() {
        add_action('after_setup_theme', array($this, 'theme_setup'));
        add_action('wp_enqueue_scripts', array($this, 'enqueue_scripts'));
        add_action('customize_register', array($this, 'customize_register'));
        add_action('widgets_init', array($this, 'register_sidebars'));
        add_action('wp_ajax_rp_filter_products', array($this, 'ajax_filter_products'));
        add_action('wp_ajax_nopriv_rp_filter_products', array($this, 'ajax_filter_products'));
        add_action('wp_ajax_rp_add_to_cart', array($this, 'ajax_add_to_cart'));
        add_action('wp_ajax_nopriv_rp_add_to_cart', array($this, 'ajax_add_to_cart'));
        
        // WooCommerce hooks
        add_action('woocommerce_loaded', array($this, 'woocommerce_support'));
        
        $this->includes();
    }
    
    /**
     * Theme setup
     */
    public function theme_setup() {
        load_theme_textdomain('restropress', get_template_directory() . '/languages');
        
        add_theme_support('title-tag');
        add_theme_support('post-thumbnails');
        add_theme_support('custom-logo');
        add_theme_support('html5', array(
            'search-form',
            'comment-form',
            'comment-list',
            'gallery',
            'caption',
            'style',
            'script',
        ));
        
        add_theme_support('customize-selective-refresh-widgets');
        add_theme_support('responsive-embeds');
        add_theme_support('editor-styles');
        
        // WooCommerce support
        add_theme_support('woocommerce');
        add_theme_support('wc-product-gallery-zoom');
        add_theme_support('wc-product-gallery-lightbox');
        add_theme_support('wc-product-gallery-slider');
        
        register_nav_menus(array(
            'primary' => __('منوی اصلی', 'restropress'),
            'footer' => __('منوی فوتر', 'restropress'),
            'mobile' => __('منوی موبایل', 'restropress'),
        ));
        
        // Custom image sizes
        add_image_size('rp-product-thumb', 400, 300, true);
        add_image_size('rp-hero-bg', 1920, 1080, true);
        add_image_size('rp-category-thumb', 300, 200, true);
    }
    
    /**
     * Enqueue scripts and styles
     */
    public function enqueue_scripts() {
        // Styles
        wp_enqueue_style('restropress-style', get_stylesheet_uri(), array(), RESTROPRESS_VERSION);
        wp_enqueue_style('rp-main-style', RESTROPRESS_TEMPLATE_URL . '/assets/css/main.css', array('restropress-style'), RESTROPRESS_VERSION);
        wp_enqueue_style('rp-responsive-style', RESTROPRESS_TEMPLATE_URL . '/assets/css/responsive.css', array('rp-main-style'), RESTROPRESS_VERSION);
        
        // Google Fonts
        wp_enqueue_style('rp-google-fonts', 'https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;500;600;700&family=Open+Sans:wght@300;400;500;600;700&family=Roboto:wght@300;400;500;700&display=swap', array(), null);
        
        // Font Awesome for icons
        wp_enqueue_style('rp-font-awesome', 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css', array(), '6.0.0');
        
        // Scripts
        wp_enqueue_script('rp-main-js', RESTROPRESS_TEMPLATE_URL . '/assets/js/main.js', array('jquery'), RESTROPRESS_VERSION, true);
        wp_enqueue_script('rp-ajax-menu', RESTROPRESS_TEMPLATE_URL . '/assets/js/ajax-menu.js', array('jquery', 'rp-main-js'), RESTROPRESS_VERSION, true);
        
        // Localize script for AJAX
        wp_localize_script('rp-ajax-menu', 'rp_ajax', array(
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('rp_nonce'),
            'loading_text' => __('در حال بارگذاری...', 'restropress'),
            'error_text' => __('خطا در بارگذاری', 'restropress'),
            'add_to_cart_text' => __('افزودن به سبد خرید', 'restropress'),
            'added_to_cart_text' => __('اضافه شد!', 'restropress')
        ));
        
        // Add inline CSS for customizer options
        $this->add_inline_styles();
    }
    
    /**
     * Add inline styles from customizer
     */
    public function add_inline_styles() {
        $primary_color = get_theme_mod('rp_primary_color', '#c8a97e');
        $secondary_color = get_theme_mod('rp_secondary_color', '#1a1a1a');
        $accent_color = get_theme_mod('rp_accent_color', '#d4af37');
        $primary_font = get_theme_mod('rp_primary_font', 'Playfair Display');
        $secondary_font = get_theme_mod('rp_secondary_font', 'Open Sans');
        $body_font = get_theme_mod('rp_body_font', 'Roboto');
        
        $custom_css = "
            :root {
                --rp-primary-color: {$primary_color};
                --rp-secondary-color: {$secondary_color};
                --rp-accent-color: {$accent_color};
                --rp-primary-font: '{$primary_font}', serif;
                --rp-secondary-font: '{$secondary_font}', sans-serif;
                --rp-body-font: '{$body_font}', sans-serif;
            }
        ";
        
        wp_add_inline_style('rp-main-style', $custom_css);
    }
    
    /**
     * Customizer settings
     */
    public function customize_register($wp_customize) {
        require_once RESTROPRESS_TEMPLATE_PATH . '/inc/customizer.php';
    }
    
    /**
     * Register sidebars
     */
    public function register_sidebars() {
        register_sidebar(array(
            'name' => __('سایدبار اصلی', 'restropress'),
            'id' => 'main-sidebar',
            'description' => __('ویجت‌های نمایش داده شده در سایدبار اصلی', 'restropress'),
            'before_widget' => '<div id="%1$s" class="widget %2$s">',
            'after_widget' => '</div>',
            'before_title' => '<h3 class="widget-title">',
            'after_title' => '</h3>',
        ));
        
        register_sidebar(array(
            'name' => __('فوتر بخش ۱', 'restropress'),
            'id' => 'footer-1',
            'description' => __('ویجت‌های بخش اول فوتر', 'restropress'),
            'before_widget' => '<div id="%1$s" class="widget %2$s">',
            'after_widget' => '</div>',
            'before_title' => '<h3 class="widget-title">',
            'after_title' => '</h3>',
        ));
        
        register_sidebar(array(
            'name' => __('فوتر بخش ۲', 'restropress'),
            'id' => 'footer-2',
            'description' => __('ویجت‌های بخش دوم فوتر', 'restropress'),
            'before_widget' => '<div id="%1$s" class="widget %2$s">',
            'after_widget' => '</div>',
            'before_title' => '<h3 class="widget-title">',
            'after_title' => '</h3>',
        ));
    }
    
    /**
     * AJAX filter products
     */
    public function ajax_filter_products() {
        check_ajax_referer('rp_nonce', 'nonce');
        
        $category_id = isset($_POST['category_id']) ? intval($_POST['category_id']) : 0;
        
        $args = array(
            'post_type' => 'product',
            'posts_per_page' => -1,
            'post_status' => 'publish'
        );
        
        if ($category_id > 0) {
            $args['tax_query'] = array(
                array(
                    'taxonomy' => 'product_cat',
                    'field' => 'term_id',
                    'terms' => $category_id
                )
            );
        }
        
        $products = new WP_Query($args);
        
        ob_start();
        
        if ($products->have_posts()) {
            while ($products->have_posts()) {
                $products->the_post();
                global $product;
                ?>
                <div class="rp-product-card">
                    <?php if (has_post_thumbnail()) : ?>
                        <img src="<?php echo get_the_post_thumbnail_url(get_the_ID(), 'rp-product-thumb'); ?>" alt="<?php the_title(); ?>" class="rp-product-image">
                    <?php endif; ?>
                    
                    <div class="rp-product-info">
                        <h3 class="rp-product-title"><?php the_title(); ?></h3>
                        
                        <?php if (get_the_excerpt()) : ?>
                            <p class="rp-product-description"><?php echo wp_trim_words(get_the_excerpt(), 15); ?></p>
                        <?php endif; ?>
                        
                        <div class="rp-product-price">
                            <?php echo $product->get_price_html(); ?>
                        </div>
                        
                        <button class="rp-add-to-cart" data-product-id="<?php echo get_the_ID(); ?>">
                            <i class="fas fa-shopping-cart"></i>
                            <?php _e('افزودن به سبد خرید', 'restropress'); ?>
                        </button>
                    </div>
                </div>
                <?php
            }
            wp_reset_postdata();
        } else {
            echo '<div class="rp-no-products rp-text-center">';
            echo '<i class="fas fa-utensils" style="font-size: 3rem; color: #ccc; margin-bottom: 1rem;"></i>';
            echo '<p>' . __('محصولی در این دسته بندی یافت نشد.', 'restropress') . '</p>';
            echo '</div>';
        }
        
        $output = ob_get_clean();
        
        wp_send_json_success($output);
        
        wp_die();
    }
    
    /**
     * AJAX add to cart
     */
    public function ajax_add_to_cart() {
        check_ajax_referer('rp_nonce', 'nonce');
        
        $product_id = isset($_POST['product_id']) ? intval($_POST['product_id']) : 0;
        $quantity = isset($_POST['quantity']) ? intval($_POST['quantity']) : 1;
        
        if ($product_id === 0) {
            wp_send_json_error(__('محصول معتبر نیست.', 'restropress'));
        }
        
        // Check if WooCommerce is active
        if (!class_exists('WooCommerce')) {
            wp_send_json_error(__('ووکامرس فعال نیست.', 'restropress'));
        }
        
        // Add to cart
        $cart_item_key = WC()->cart->add_to_cart($product_id, $quantity);
        
        if ($cart_item_key) {
            $response = array(
                'success' => true,
                'message' => __('محصول به سبد خرید اضافه شد.', 'restropress'),
                'cart_count' => WC()->cart->get_cart_contents_count(),
                'cart_total' => WC()->cart->get_cart_total()
            );
            wp_send_json_success($response);
        } else {
            wp_send_json_error(__('خطا در افزودن به سبد خرید.', 'restropress'));
        }
        
        wp_die();
    }
    
    /**
     * WooCommerce support
     */
    public function woocommerce_support() {
        // Remove WooCommerce default styles
        add_filter('woocommerce_enqueue_styles', '__return_empty_array');
        
        // Modify WooCommerce wrappers
        remove_action('woocommerce_before_main_content', 'woocommerce_output_content_wrapper', 10);
        remove_action('woocommerce_after_main_content', 'woocommerce_output_content_wrapper_end', 10);
        
        add_action('woocommerce_before_main_content', array($this, 'woocommerce_wrapper_start'), 10);
        add_action('woocommerce_after_main_content', array($this, 'woocommerce_wrapper_end'), 10);
    }
    
    /**
     * WooCommerce wrapper start
     */
    public function woocommerce_wrapper_start() {
        echo '<div class="rp-container"><div class="rp-woocommerce-content">';
    }
    
    /**
     * WooCommerce wrapper end
     */
    public function woocommerce_wrapper_end() {
        echo '</div></div>';
    }
    
    /**
     * Include required files
     */
    private function includes() {
        require_once RESTROPRESS_TEMPLATE_PATH . '/inc/custom-functions.php';
        require_once RESTROPRESS_TEMPLATE_PATH . '/inc/customizer.php';
        require_once RESTROPRESS_TEMPLATE_PATH . '/inc/ajax-handler.php';
    }
}

// Initialize the theme
new RestroPress_Theme();

/**
 * Helper function to get theme mod with default
 */
function rp_get_theme_mod($key, $default = '') {
    return get_theme_mod('rp_' . $key, $default);
}

/**
 * Get hero background
 */
function rp_get_hero_background() {
    $bg_type = rp_get_theme_mod('hero_bg_type', 'image');
    
    if ($bg_type === 'color') {
        return rp_get_theme_mod('hero_bg_color', '#1a1a1a');
    } else {
        $bg_image = rp_get_theme_mod('hero_bg_image', '');
        return $bg_image ? 'url(' . esc_url($bg_image) . ')' : 'url(' . RESTROPRESS_TEMPLATE_URL . '/assets/images/default-hero.jpg)';
    }
}

/**
 * Get footer contact info
 */
function rp_get_footer_contact() {
    return array(
        'address' => rp_get_theme_mod('footer_address', ''),
        'phone' => rp_get_theme_mod('footer_phone', ''),
        'email' => rp_get_theme_mod('footer_email', ''),
        'instagram' => rp_get_theme_mod('footer_instagram', ''),
        'whatsapp' => rp_get_theme_mod('footer_whatsapp', '')
    );
}

/**
 * Display product categories for menu filter
 */
function rp_display_product_categories() {
    $categories = get_terms(array(
        'taxonomy' => 'product_cat',
        'hide_empty' => true,
        'parent' => 0
    ));
    
    if (!empty($categories) && !is_wp_error($categories)) {
        echo '<button class="rp-category-btn active" data-category-id="0">' . __('همه موارد', 'restropress') . '</button>';
        
        foreach ($categories as $category) {
            echo '<button class="rp-category-btn" data-category-id="' . $category->term_id . '">' . $category->name . '</button>';
        }
    }
}
?>